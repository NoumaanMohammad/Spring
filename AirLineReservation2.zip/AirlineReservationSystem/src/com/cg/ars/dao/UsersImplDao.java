package com.cg.ars.dao;

public class UsersImplDao {

}
