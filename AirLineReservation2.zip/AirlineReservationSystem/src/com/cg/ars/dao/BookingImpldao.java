package com.cg.ars.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;
import com.cg.ars.util.DBConnection;

public class BookingImpldao implements IBookingInfoDao{
	@Override
	public int book_tickets(BookingInformationDto bid) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		int booking_id=bdto.setBooking_id(gen_booking_id());
		//double ticket_fare=bdto.setTotal_fare(total_tickets_fare(bdto.getNo_of_passengers()));
		String ins="insert into BookingInformation values(?,?,?,?,?,?,?,?,?)"; 
		try {
			PreparedStatement ps=conn.prepareStatement(ins);
			ps.setInt(1, bdto.getBooking_id());//from sequence
			ps.setString(2,bdto.getCust_email());
			ps.setInt(3,bdto.getNo_of_passengers());
			ps.setString(4, bdto.getClass_type());
			ps.setDouble(5,bdto.getTotal_fare());//calculate the price
			ps.setString(6, bdto.getClass_type());
			ps.setString(7,bdto.getSeat_number());
			ps.setString(8,bdto.getCard_type().toString()+","+bdto.getUser_name().toString()+","+bdto.getCreditCard_info().toString()+","+bdto.getCvv()+","+bdto.getDoe()+","+bdto.getYoe());
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return booking_id;
	}
	public int gen_booking_id()
	{
		int booking_id=0;
		String gen_id="select booking_id_seq.nextval from dual";
		return booking_id;
		
	}
	
	
	
	@Override
	public double total_ticket_fare(BookingInformationDto bid,FlightInformationDto fid) {
		double total_fare=0;
		if(bid.getClass_type()=="First Class")
		{
			//String sql="Select "
		}
		return total_fare;
	}
	
	
	@Override
	public BookingInformationDto view_booking_details(int booking_id) throws AirlineReservationException {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto1=new BookingInformationDto();
		String sql2="Select * from BookingInformation where Booking_id=?";
		
		try {
			PreparedStatement ps=conn.prepareStatement(sql2);
			ps.setInt(1, booking_id);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
			int flight_no=rs.getInt("flightno");
			String email=rs.getString("cust_email");
			int no_passengers=rs.getInt("no_of_passengers");
			String class_type=rs.getString("class_type");
			double total_fare=rs.getDouble("total_fare");
			String seat_no=rs.getString("seat_number");
			String cc_info=rs.getString("CreditCard_info");
			String src_city=rs.getString("src_city");
			String dest_city=rs.getString("dest_city");
			
			bdto1.setFlightno(flight_no);
			bdto1.setCust_email(email);
			bdto1.setNo_of_passengers(no_passengers);
			bdto1.setClass_type(class_type);
			bdto1.setTotal_fare(total_fare);
			bdto1.setSeat_number_final(seat_no);
			bdto1.setDest_city(dest_city);
			bdto1.setSrc_city(src_city);
			}
		} catch (SQLException e) {
			throw new AirlineReservationException("not able to retrieve data");
		}
		
		return bdto1;
	}
	
	
	@Override
	public boolean seat_availability_check(String seat_no_single) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		String sql4="Select booking_id from bookinginformation where seat_number=? ";
		
		try {
			PreparedStatement ps3=conn.prepareStatement(sql4);
			ps3.setString(1,seat_no_single);
			ResultSet rs=ps3.executeQuery();
			if(rs.next())
			{
			int bkId=rs.getInt("booking_id");
			if(bkId<0)
			{
				return true;//seat available
			}}else return false;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
		
	}
	@Override
	public BookingInformationDto update_date(Date date_update) {
		
		return null;
	}
	@Override
	public BookingInformationDto update_class(String class_update,int booking_id) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		String sql5="update table bookingInformation set class_type=? where booking_id=? ";
		String sql_sel="select Booking_id,flightno,cust_email,no_of_passengers,total_fare,seat_number,src_city,dest_city from bookingInformation where booking_id=?";
		PreparedStatement ps4;
		try {
			ps4 = conn.prepareStatement(sql5);
			ps4.setInt(2,booking_id);
			ps4.setString(1, class_update);
			PreparedStatement st=conn.prepareStatement(sql_sel);
			ResultSet rs1=st.executeQuery();
			if(rs1.next())
			{
				bdto.setBooking_id(rs1.getInt("booking_id"));
				bdto.setFlightno(rs1.getInt("flight_no"));
				bdto.setCust_email(rs1.getString("cust_email"));
				bdto.setNo_of_passengers(rs1.getInt("no_of_passengers"));
				bdto.setClass_type(rs1.getString("class_type"));
				bdto.setSeat_no_single(rs1.getString("seat_number"));
				bdto.setSrc_city(rs1.getString("src_city"));
				bdto.setDest_city(rs1.getString("dest_city"));
				bdto.setTotal_fare(rs1.getDouble("total_fare"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 
		return bdto;
	}
	@Override
	public BookingInformationDto update_source(String src_update,int booking_id) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		String sql5="update table bookingInformation set src_city=? where booking_id=? ";
		String sql_sel="select Booking_id,flightno,cust_email,no_of_passengers,total_fare,seat_number,src_city,dest_city from bookingInformation";
		PreparedStatement ps4;
		try {
			ps4 = conn.prepareStatement(sql5);
			ps4.setInt(2,booking_id);
			ps4.setString(1, src_update);
			PreparedStatement st=conn.prepareStatement(sql_sel);
			st.setInt(1,booking_id);
			ResultSet rs1=st.executeQuery();
			if(rs1.next())
			{
				bdto.setBooking_id(rs1.getInt("booking_id"));
				bdto.setFlightno(rs1.getInt("flight_no"));
				bdto.setCust_email(rs1.getString("cust_email"));
				bdto.setNo_of_passengers(rs1.getInt("no_of_passengers"));
				bdto.setClass_type(rs1.getString("class_type"));
				bdto.setSeat_no_single(rs1.getString("seat_number"));
				bdto.setSrc_city(rs1.getString("src_city"));
				bdto.setDest_city(rs1.getString("dest_city"));
				bdto.setTotal_fare(rs1.getDouble("total_fare"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return bdto;
	}
	@Override
	public BookingInformationDto update_destination(String dest_update,int booking_id) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		String sql5="update table bookingInformation set dest_city=? where booking_id=? ";
		String sql_sel="select Booking_id,flightno,cust_email,no_of_passengers,total_fare,seat_number,src_city,dest_city from bookingInformation where booking_id=?";
		PreparedStatement ps4;
		try {
			ps4 = conn.prepareStatement(sql5);
			ps4.setInt(2,booking_id);
			ps4.setString(1, dest_update);
			PreparedStatement st=conn.prepareStatement(sql_sel);
			st.setInt(1,booking_id);
			ResultSet rs1=st.executeQuery();
			if(rs1.next())
			{
				bdto.setBooking_id(rs1.getInt("booking_id"));
				bdto.setFlightno(rs1.getInt("flight_no"));
				bdto.setCust_email(rs1.getString("cust_email"));
				bdto.setNo_of_passengers(rs1.getInt("no_of_passengers"));
				bdto.setClass_type(rs1.getString("class_type"));
				bdto.setSeat_no_single(rs1.getString("seat_number"));
				bdto.setSrc_city(rs1.getString("src_city"));
				bdto.setDest_city(rs1.getString("dest_city"));
				bdto.setTotal_fare(rs1.getDouble("total_fare"));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			
		}
		return bdto;
	}
	@Override
	public BookingInformationDto deleteBooking(int booking_id) throws AirlineReservationException {
		Connection conn=DBConnection.getConnection();
		
		BookingInformationDto bdto=new BookingInformationDto();
		String sql_sel="select * from bookingInformation where booking_id=? ";
		try {
			PreparedStatement s=conn.prepareStatement(sql_sel);
			s.setInt(1,booking_id);
			ResultSet rs=s.executeQuery();
			if(rs.next())
			{
				bdto.setFlightno(rs.getInt("flightno"));
				bdto.setNo_of_passengers(rs.getInt("no_of_passengers"));
				bdto.setClass_type(rs.getString("class_type"));
				deleteBookingInfo(booking_id);
			}
		} catch (SQLException e) {
			
			System.out.println(e.getMessage());
		}
		return bdto;
		
		
	}
	@Override
	public BookingInformationDto updateDetails(int booking_id, String src,String dest) {
		Connection conn=DBConnection.getConnection();
		BookingInformationDto bdto=new BookingInformationDto();
		String sql="update bookingInformation set src_city=?,dest_city=? where booking_id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, src);
			ps.setString(2, dest);
			ps.setInt(3,booking_id);
			ResultSet rs=ps.executeQuery();
			rs.next();
					
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		String sql_sel="select * from bookingInformation where booking_id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql_sel);
		ps.setInt(1,booking_id);
		ResultSet rs=ps.executeQuery();
		
		if(rs.next())
		{
			bdto.setBooking_id(rs.getInt("booking_id"));
			bdto.setFlightno(rs.getInt("flightno"));
			bdto.setCust_email(rs.getString("cust_email"));
			bdto.setNo_of_passengers(rs.getInt("no_of_passengers"));
			bdto.setClass_type(rs.getString("class_type"));
			bdto.setSeat_no_single(rs.getString("seat_number"));
			bdto.setSrc_city(rs.getString("src_city"));
			bdto.setDest_city(rs.getString("dest_city"));
			bdto.setTotal_fare(rs.getDouble("total_fare"));
		}
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return bdto;
	}
	public void deleteBookingInfo(int booking_id) throws AirlineReservationException
	{
		Connection conn=DBConnection.getConnection();
	String sql6="delete from bookingInformation where Booking_id=? ";
	try {
		PreparedStatement ps=conn.prepareStatement(sql6);
		ps.setInt(1,booking_id);
		//rows=ps.executeUpdate();
		
	} catch (SQLException e) {
		
		throw new AirlineReservationException("cannot able to delete data");
	}
	}
}















































































