package com.cg.ars.dao;

import java.util.Date;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;


public interface IBookingInfoDao {
	public  int book_tickets(BookingInformationDto bid);
	public double total_ticket_fare(BookingInformationDto bid,FlightInformationDto fid);
	public BookingInformationDto view_booking_details(int booking_id) throws AirlineReservationException;
	public boolean seat_availability_check(String seat_no_single);
	public BookingInformationDto update_date(Date date_update);
	public BookingInformationDto update_class(String class_update, int booking_id);
	public BookingInformationDto update_source(String src_update, int booking_id);
	public BookingInformationDto update_destination(String dest_update, int booking_id);
	public BookingInformationDto deleteBooking(int booking_id) throws AirlineReservationException;
	public BookingInformationDto updateDetails(int booking_id, String src,
			String dest);
	
}
