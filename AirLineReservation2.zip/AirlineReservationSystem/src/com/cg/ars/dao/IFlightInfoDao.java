package com.cg.ars.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;

public interface IFlightInfoDao {
	public ArrayList<FlightInformationDto> display_details(String src_city,String dest_city) throws AirlineReservationException;
	public FlightInformationDto check_flight_no(int fl_no);
	public void update_seats_available(int no_passengers, int fl_no, String class_type) throws AirlineReservationException;
	public void updateCancelledSeats(int noOfPsngr, String classType, int flNo) throws AirlineReservationException;
}
