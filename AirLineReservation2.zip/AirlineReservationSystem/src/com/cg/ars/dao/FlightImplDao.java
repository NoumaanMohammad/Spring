package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;
import com.cg.ars.util.DBConnection;

public class FlightImplDao implements IFlightInfoDao{
	Connection conn=DBConnection.getConnection();
	ArrayList<FlightInformationDto> flist=new ArrayList<FlightInformationDto>();
	FlightInformationDto fdto=new FlightInformationDto();
	BookingInformationDto bdto=new BookingInformationDto();
	public ArrayList<FlightInformationDto> display_details(String src_city,String dest_city) throws AirlineReservationException		{
	String sql="select * from flightinformation where arr_city=? and dep_city=?";
		System.out.println("reached");
	try {
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(2,src_city);
		pstmt.setString(1,dest_city);
		ResultSet res=pstmt.executeQuery();
		if(res!=null)
		{
			while(res.next())
			{
			int flight_no=res.getInt("flightno");
			String airline=res.getString("airline");
			String arr_city=res.getString("arr_city");
			String dept_city=res.getString("dep_city");
			Date dept_date=res.getDate("dep_date");
			Date arr_date=res.getDate("arr_date");
			String dept_time=res.getString("dep_time");
			String arr_time=res.getString("arr_time");
			int first_seat_no=res.getInt("FirstSeats");
			double first_seat_fare=res.getDouble("FirstSeatFare");
			int buss_seat_no=res.getInt("BussSeats");
			double buss_seat_fare=res.getDouble("BussSeatsFare");
			
			fdto.setFlightno(flight_no);
			fdto.setAirline(airline);		
			fdto.setArr_city(arr_city);
			fdto.setDep_city(dept_city);
			fdto.setDep_date(dept_date);
			fdto.setArr_date(arr_date);
			fdto.setDep_date(dept_date);
			fdto.setArr_time(arr_time);
			fdto.setDep_time(dept_time);
			fdto.setArr_time(arr_time);
			fdto.setFirstSeats(first_seat_no);
			fdto.setFirstSeatFare(first_seat_fare);
			fdto.setBussSeats(buss_seat_no);
			fdto.setBussSeatsFare(buss_seat_fare);
			flist.add(fdto);
	}
		}else if(res==null)
		{
			System.out.println("Flights not found for your destination city and arrival city");
		}
		
	} catch (SQLException e) {
		throw new AirlineReservationException("not able to retrieve data");
	}
	System.out.println("checking");
	return flist;
	}
	@Override
	public FlightInformationDto check_flight_no(int fl_no) {
		Connection conn=DBConnection.getConnection();
		String sql3="Select airline,dep_city,arr_city,dep_date,arr_date,"
				+ "dep_time,arr_time,FirstSeats,FirstSeatFare,BussSeats,"
				+ "BussSeatsFare from flightinformation where flightno=?";
				try {
			PreparedStatement ps=conn.prepareStatement(sql3);
			ps.setInt(1, fl_no);
			ResultSet res1=ps.executeQuery();
			if(res1.next());
			{
				
			
			String airline=res1.getString("airline");
			String dept_city=res1.getString("dep_city");
			String arr_city=res1.getString("arr_city");
			Date dept_date=res1.getDate("dep_date");
			Date arr_date=res1.getDate("arr_date");
			String dept_time=res1.getString("dep_time");
			String arr_time=res1.getString("arr_time");
			int first_seat_no=res1.getInt("FirstSeats");
			double first_seat_fare=res1.getDouble("FirstSeatFare");
			int buss_seat_no=res1.getInt("BussSeats");
			double buss_seat_fare=res1.getDouble("BussSeatsFare");
			
			
			fdto.setAirline(airline);		
			fdto.setArr_city(arr_city);
			fdto.setDep_city(dept_city);
			fdto.setDep_date(dept_date);
			fdto.setArr_date(arr_date);
			fdto.setDep_date(dept_date);
			fdto.setArr_time(arr_time);
			fdto.setDep_time(dept_time);
			fdto.setArr_time(arr_time);
			fdto.setFirstSeats(first_seat_no);
			fdto.setFirstSeatFare(first_seat_fare);
			fdto.setBussSeats(buss_seat_no);
			fdto.setBussSeatsFare(buss_seat_fare);
		} }catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return fdto;
	}
	@Override
	public void update_seats_available(int no_passengers, int fl_no,String class_type) throws AirlineReservationException {
		Connection conn=DBConnection.getConnection();
		if(class_type.equals("first class"))
		{
			String sql="update flightinformation set FirstSeats=FirstSeats-? where fl_no=?";
			
			try {
				PreparedStatement ps=conn.prepareStatement(sql);
				ps.setInt(1, no_passengers);
				ps.setInt(2, fl_no);
			} catch (SQLException e) {
				throw new AirlineReservationException("cannot update");
			}
			
		}else if(class_type.equals("business class"))
		{
			String sql="update flightinformation set BussSeats=BussSeats-? where fl_no=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, no_passengers);
				ps.setInt(2, fl_no);
			} catch (SQLException e) {
				
				throw new AirlineReservationException("cannot update");
			}
			
		}
	
		
		
	}
	
	@Override
	public void updateCancelledSeats(int noOfPsngr, String classType,int flNo) throws AirlineReservationException {
		
		Connection conn=DBConnection.getConnection();
		if(classType.equals("first class"))
		{
			String sql="update flightinformation set FirstSeats=FirstSeats-? where fl_no=?";
			
			try {
				PreparedStatement ps=conn.prepareStatement(sql);
				ps.setInt(1, noOfPsngr);
				ps.setInt(2, flNo);
			} catch (SQLException e) {
				throw new AirlineReservationException("cannot update");
			}
			
		}else if(classType.equals("business class"))
		{
			String sql="update flightinformation set BussSeats=BussSeats-? where fl_no=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, noOfPsngr);
				ps.setInt(2, flNo);
			} catch (SQLException e) {
				
				throw new AirlineReservationException("cannot update");
			}
			
		}	
	}
	}
