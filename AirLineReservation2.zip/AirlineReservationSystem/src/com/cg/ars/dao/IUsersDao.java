package com.cg.ars.dao;

public interface IUsersDao {

}
