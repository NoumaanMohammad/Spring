package com.cg.ars.exception;

public class AirlineReservationException extends Exception{

	public AirlineReservationException() {
	
	}

	public AirlineReservationException(String msg) {
		super(msg);
	}
	
	

}
