package com.cg.ars.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	public static Connection getConnection()
	{
		String url="";
		String username="";
		String password="";
		String driver="";
		Connection connection = null;
				try {
					InputStream in=new FileInputStream("jdbc.properties");
					Properties pr= new Properties();
					pr.load(in);
					url=pr.getProperty("url");
					username=pr.getProperty("username");
					password=pr.getProperty("pwd");
					driver=pr.getProperty("driver");
					Class.forName(driver);
					connection= DriverManager.getConnection(url, username, password);
					//if(connection!=null)
						System.out.println("Connected to Database");
					
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		return connection;
		
	}
	public static void main(String args[])
	{
		getConnection();
	}
}
