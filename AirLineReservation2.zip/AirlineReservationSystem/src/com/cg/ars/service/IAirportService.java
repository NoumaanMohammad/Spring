package com.cg.ars.service;

public interface IAirportService {

}
