package com.cg.ars.service;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ars.dao.BookingImpldao;
import com.cg.ars.dao.IBookingInfoDao;
import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;

public class BookingInfoService implements IBookingInfoService{
	IBookingInfoDao bdao=new BookingImpldao();

	@Override
	public int book_tickets(BookingInformationDto bid) {
		return bdao.book_tickets(bid);
	}

	@Override
	public double total_tickets_fare(BookingInformationDto bid,FlightInformationDto fid) {
		IBookingInfoDao bdao=new BookingImpldao();
		return bdao.total_ticket_fare(bid, fid);
	}

	@Override
	public boolean input_validation(BookingInformationDto bid) {
		Date now = null;
		int year = now.getYear();
		int date=now.getDate();
		BookingInformationDto bdto=new BookingInformationDto();
		Pattern em_pat=Pattern.compile("[a-z||0-9]{3,20}@[a-z]{3,20}.[a-z]{2,4}");
		Matcher em_matcher=em_pat.matcher(bdto.getCust_email());
		if(em_matcher.matches())
		{
			if(bdto.getNo_of_passengers()<=0)
			{
				if(bdto.getNo_of_passengers()<=0)
					{
					if(bdto.getCard_type().toLowerCase()=="first class" || bdto.getCard_type().toLowerCase()=="business class")
						{
							Pattern seat_pat=Pattern.compile("[A-Z]{4}[0-9]{2,4}");
							Matcher seat_matcher=seat_pat.matcher(bdto.getSeat_number());
							if(seat_matcher.matches())
							{
								if(bdto.getCard_type().toLowerCase()=="visa")
								{
									Pattern p_visa=Pattern.compile("4\\ d{ 12} (\\ d{ 3} )?");
									Matcher matcher_visa=p_visa.matcher(bid.getCard_type());
									if(bdto.getCvv()>=100 || bdto.getCvv()<=999)
									{
										if(bdto.getYoe()==year)
										{
											if(bdto.getDoe()<date)
											{
												return true;
											}
										}else if(bdto.getYoe()<year)
										{
											return true;
										}else return false;
									}else return false;
								}else if(bdto.getCard_type().toLowerCase()=="american express")
								{
									Pattern p_american_express=Pattern.compile("3[47]\\ d{ 13}");
									Matcher matcher_am_ex=p_american_express.matcher(bid.getClass_type());
									if(bdto.getCvv()>=100 || bdto.getCvv()<=999)
									{
										if(bdto.getYoe()==year)
										{
											if(bdto.getDoe()<date)
											{
												return true;
											}
										}else if(bdto.getYoe()<year)
										{
											return true;
										}else return false;
									}else return false;
																		
								}else if(bdto.getCard_type().toLowerCase()=="master card")
								{
									Pattern p_master_card=Pattern.compile("5[1-5]\\ d{ 14}");
									Matcher matcher_master_card=p_master_card.matcher(bid.getClass_type());
									if(bdto.getCvv()>=100 || bdto.getCvv()<=999)
									{
										if(bdto.getYoe()==year)
										{
											if(bdto.getDoe()>date)
											{
												return true;
											}
										}else if(bdto.getYoe()>year)
										{
											return true;
										}else return false;
									}else return false;
								}else return false;
							}else return false;
						}else return false;
					}else return false;
				}else return false;
			}else return false;
		
		return false;
	}

	@Override
	public BookingInformationDto view_booking_details(int booking_id) throws AirlineReservationException {
		return bdao.view_booking_details(booking_id);
	}

	@Override
	public BookingInformationDto update_date(Date date_update) {
		return bdao.update_date(date_update);
	}

	@Override
	public BookingInformationDto update_class(String class_update,int booking_id) {
		return bdao.update_class(class_update,booking_id);
	}

	@Override
	public BookingInformationDto update_source(String src_update,int booking_id) {
		return bdao.update_source(src_update,booking_id);
	}

	@Override
	public BookingInformationDto update_destination(String dest_update,int booking_id) {
		return bdao.update_destination(dest_update,booking_id);
	}

	@Override
	public boolean seat_availability_check(String seat_no_single) {
		return bdao.seat_availability_check(seat_no_single);
	}

	@Override
	public BookingInformationDto deleteBooking(int booking_id) throws AirlineReservationException {
		return bdao.deleteBooking(booking_id);
	}

	public BookingInformationDto updateDetails(int booking_id, String src, String dest) {
		return bdao.updateDetails(booking_id,src,dest);
	}

	

	

	
	

}
