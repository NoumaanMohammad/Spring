package com.cg.ars.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dao.FlightImplDao;
import com.cg.ars.dao.IFlightInfoDao;
import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;

public class FlightInfoService implements IFlightInfoService{
	IFlightInfoDao fdao=new FlightImplDao();
	@Override
	public ArrayList<FlightInformationDto> display_details(String src_city,String dest_city) throws AirlineReservationException {
		return fdao.display_details(src_city,dest_city);
		
	}

	public FlightInformationDto check_flight_no(int fl_no) {
		return fdao.check_flight_no(fl_no);
	}

	@Override
	public void update_seats_available(int no_passengers,int fl_no,String class_type) throws AirlineReservationException {
		fdao.update_seats_available(no_passengers,fl_no,class_type);
		
	}

	@Override
	public void updateCancelledSeats(int noOfPsngr, String classType,int flNo ) throws AirlineReservationException {
		fdao.updateCancelledSeats(noOfPsngr,classType,flNo);
		
	}


	
}
