package com.cg.ars.pl;

import java.awt.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

import com.cg.ars.dao.FlightImplDao;
import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.AirlineReservationException;
import com.cg.ars.service.BookingInfoService;
import com.cg.ars.service.FlightInfoService;
import com.cg.ars.service.IBookingInfoService;
import com.cg.ars.service.IFlightInfoService;

public class main_pl {
	public void main_menu() throws AirlineReservationException
	{
	String ch_main = "";
	Scanner s=new Scanner(System.in);
	
	int i,choice,role;
	String ch_user;
	
	
		do
		{
				System.out.println("1.ADMIN");
				System.out.println("\n2.AIRLINE EXECUTIVE");
				System.out.println("\n3.USERS");
				System.out.println("\n4.EXIT");
				System.out.println("\nInput the role");
				role=s.nextInt();
				switch(role)
				{
					case 1://admin
						{
							
						}
						break;
						case 2://airline executive
						{
							
						}
						break;
						case 3:
						{
							user_menu();
						}
						break;
						case 4:
						{
							System.exit(0);
						}
						default:System.out.println("Do you want to continue");
						ch_main=s.next();
			}
			
		}while(ch_main.toLowerCase().equals("yes"));	
	}
	public void user_menu() throws AirlineReservationException
	{
		int choice=0;
		Scanner s=new Scanner(System.in);
		String ch_user="";
		do
		{
			System.out.println("\n1.Book a flight ticket");
			System.out.println("\n2.View a booked flight ticket");
			System.out.println("\n3.Update the flight ticket details");
			System.out.println("\n4.Cancel the flight ticket");
			System.out.println("\n5.Back to main menu");
			//System.out.println("\n6.Exit");
			System.out.println("Input the choice");
			choice=s.nextInt();
			switch(choice)
			{
			case 1:
			{
				
				users_case_1();
			}
			break;
			case 2:
			{
				user_case_2();
			}
			break;
			case 3:
			{
				user_case_3();
			}
			break;
			case 4:
			{
				user_case_4();
			}
			break;
			case 5:
			{
				main_menu();
			}
			break;
			
			
			default:System.out.println("Do you want to continue");
					ch_user=s.next();
			}

		}while(ch_user.toLowerCase().equals("yes"));
	}
	public void user_case_4() {
		// delete the ticket based on booking id
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the booking ID");
		int booking_id=s.nextInt();
		IBookingInfoService bser3=new BookingInfoService();
		IFlightInfoService fser=new FlightInfoService();
		try {
			
			BookingInformationDto bdto=bser3.deleteBooking(booking_id);
			if(bdto.getBooking_id()<=0) {
				System.out.println("Please enter valid Booking Id");
			} else
			System.out.println("Deleted successfully");
			String classType=bdto.getClass_type();
			int noOfPsngr=bdto.getNo_of_passengers();
			int flNo=bdto.getFlightno();
			fser.updateCancelledSeats(noOfPsngr,classType,flNo);
		} catch (AirlineReservationException e) {
			System.out.println("Error"+e.getMessage());
		}
		
		
	}
	public void user_case_3() {
		Scanner s=new Scanner(System.in);
		String str = "";
		IBookingInfoService bser=new BookingInfoService();
		/*do {
			// update user ticket based on date,class type,source and dest city 
			System.out.println("1.Change information related to booking date");
			System.out.println("\n2.Change information related to type of class in booking");
			System.out.println("\n3.Change information related to source of ticket booked");
			System.out.println("\n4.Change information related to destination of ticket booked");
			System.out.println("\n5.User Menu");
			System.out.println("\n6.Main Menu");
			System.out.println("\nEnter your choice");
			int ch_update=s.nextInt();
			switch(ch_update)
			{
			case 1:
			{
				//date
				System.out.println("Enter the booking ID");
				int booking_id=s.nextInt();
				SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
				String date_update1=null;
				System.out.println("\nEnter the date to be changed in the format(dd/mm/yyyy)");
				date_update1=s.next();
				Date date_update;
				try {
					date_update = sdf.parse(date_update1);
					BookingInformationDto bdto2= bser.update_date(date_update);
					System.out.println("Booking Details after updating");
					
					System.out.print("\n" +bdto2.getBooking_id() +"\t" +bdto2.getFlightno()+ "\t" + bdto2.getCust_email()+ "\t" 
					+bdto2.getNo_of_passengers() +"\t"+bdto2.getClass_type()+"\t" + bdto2.getSeat_number_final()+"\t"
					+bdto2.getSrc_city()+"\t"+bdto2.getDest_city()+"\t" +bdto2.getTotal_fare());
					
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
						
			}
			break;
			case 2:
			{
				//class
				System.out.println("Enter the booking ID");
				int booking_id=s.nextInt();
				System.out.println("\nEnter the class");
				String class_update=s.next();
				BookingInformationDto bdto2=bser.update_class(class_update,booking_id);
				System.out.println("Booking Details after updating");
				System.out.print("\n" +bdto2.getBooking_id() +"\t" +bdto2.getFlightno()+ "\t" + bdto2.getCust_email()+ "\t" 
				+bdto2.getNo_of_passengers() +"\t"+bdto2.getClass_type()+"\t" + bdto2.getSeat_number_final()+"\t"
				+bdto2.getSrc_city()+"\t"+bdto2.getDest_city()+"\t" +bdto2.getTotal_fare());
			}
			break;
			case 3:
			{
				//source
				System.out.println("Enter the booking ID");
				int booking_id=s.nextInt();
				System.out.println("\nEnter the source");
				String src_update=s.next();
				BookingInformationDto bdto2=bser.update_source(src_update,booking_id);
				System.out.println("Booking Details after updating");
				System.out.print("\n" +bdto2.getBooking_id() +"\t" +bdto2.getFlightno()+ "\t" + bdto2.getCust_email()+ "\t" 
				+bdto2.getNo_of_passengers() +"\t"+bdto2.getClass_type()+"\t" + bdto2.getSeat_number_final()+"\t"
				+bdto2.getSrc_city()+"\t"+bdto2.getDest_city()+"\t" +bdto2.getTotal_fare());
			}
			
			break;
			case 4:
			{
				//dest
				System.out.println("Enter the booking ID");
				int booking_id=s.nextInt();
				System.out.println("\nEnter the destination");
				String dest_update=s.next();
				System.out.println("Booking Details after updating");
				BookingInformationDto bdto2=bser.update_destination(dest_update,booking_id);
				System.out.print("\n" +bdto2.getBooking_id() +"\t" +bdto2.getFlightno()+ "\t" + bdto2.getCust_email()+ "\t" 
						+bdto2.getNo_of_passengers() +"\t"+bdto2.getClass_type()+"\t" + bdto2.getSeat_number_final()+"\t"
						+bdto2.getSrc_city()+"\t"+bdto2.getDest_city()+"\t" +bdto2.getTotal_fare());
			}
			break;
			case 5:
			{
				//user menu
				user_case_3();
			}
			break;
			case 6:
			{
				//main menu
				main_menu();
			}
			default:System.out.println("Do want to continue?");
			str=s.next();
			}
		}while(str.equals("yes"));*/
		
		String ch_user="";
		BookingInformationDto bdto=new BookingInformationDto();
		System.out.println("Enter the booking ID");
		int booking_id=s.nextInt();
		System.out.println("Enter the source");
		String src=s.next();
		System.out.println("Enter the destination");
		String dest=s.next();
		bdto.setBooking_id(booking_id);
		bdto.setSrc_city(src);
		bdto.setDest_city(dest);
		BookingInformationDto bdto2=bser.updateDetails(booking_id,src,dest);
		System.out.println("Booking Details after updating");
		
		System.out.print("\n" +bdto2.getBooking_id() +"\t" +bdto2.getFlightno()+ "\t" + bdto2.getCust_email()+ "\t" 
		+bdto2.getNo_of_passengers() +"\t"+bdto2.getClass_type()+"\t" + bdto2.getSeat_number_final()+"\t"
		+bdto2.getSrc_city()+"\t"+bdto2.getDest_city()+"\t" +bdto2.getTotal_fare());
	}
	
	
	public void user_case_2() {
		//view all the details
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the booking ID");
		int booking_id=s.nextInt();
		IBookingInfoService bser2=new BookingInfoService();
		BookingInformationDto bdto1;
		try {
			bdto1 = bser2.view_booking_details(booking_id);
			System.out.print("FLIGHT NO");
			System.out.print("\t EMAIL ID");
			System.out.print("\t NO OF PASSENGERS");
			System.out.print("\t CLASS TYPE");
			System.out.print("\t TOTAL FARE");
			System.out.print("\t SEAT NUMBER(S)");
			System.out.print("\t DESTINATION CITY");
			System.out.print("\t SOURCE CITY");
			
			System.out.println(bdto1.getFlightno());
			System.out.print("\t"+bdto1.getCust_email());
			System.out.print("\t"+bdto1.getNo_of_passengers());
			System.out.print("\t"+bdto1.getClass_type());
			System.out.print("\t"+bdto1.getTotal_fare());
			
			System.out.print("\t"+bdto1.getSeat_number_final());
			System.out.print("\t"+bdto1.getDest_city());
			System.out.print("\t"+bdto1.getSrc_city());
		} catch (AirlineReservationException e) {
			System.out.println("Error"+e.getMessage());
		}
	
	}
	
	
	public void users_case_1() throws AirlineReservationException
	{
		int no_passengers=0;
		String[] seat_no=new String[120];
		BookingInformationDto bid=new BookingInformationDto();
		FlightInformationDto fid=new FlightInformationDto();
		IBookingInfoService bser=new BookingInfoService();
		IFlightInfoService fser=new FlightInfoService();
		boolean seat_val=false;
		String seat_no_fin="";
		String seat_number_final="";
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Source City");
		String src_city=s.next();
		System.out.println("Enter the Destination City");
		String dest_city=s.next();
		bid.setSrc_city(src_city);
		bid.setDest_city(dest_city);
				
		ArrayList<FlightInformationDto> falist=fser.display_details(src_city,dest_city);
		if(falist!=null)
		{
			System.out.print("FLIGHT NO");
			System.out.print("\t AIRLINE");
			System.out.print("\t ARRIVAL CITY");
			System.out.print("\t DESTINATION CITY");
			System.out.print("\t ARRIVAL DATE");
			System.out.print("\t DESTINATION DATE");
			System.out.print("\t ARRIVAL TIME");
			System.out.print("\t DESTINATION TIME");
			System.out.print("\t FIRST CLASS SEATS");
			System.out.print("\t FIRST CLASS SEATS FARE");
			System.out.print("\t BUSINESS CLASS SEATS");
			System.out.print("\tBUSINESS CLASS SEATS FARE");
			System.out.print("\t ");
			System.out.print("\t");
			for(FlightInformationDto arrfi : falist)
			{
		System.out.println(arrfi.getFlightno());
		System.out.println("\t"+arrfi.getAirline());
		System.out.print("\t"+arrfi.getArr_city());
		System.out.print("\t"+arrfi.getDep_city());
		System.out.print("\t"+arrfi.getArr_date());
		System.out.print("\t"+arrfi.getDep_date());
		System.out.print("\t"+arrfi.getArr_time());
		System.out.print("\t"+arrfi.getDep_time());
		System.out.print("\t"+arrfi.getFirstSeats());
		System.out.print("\t"+arrfi.getFirstSeatFare());
		System.out.print("\t"+arrfi.getBussSeats());
		System.out.print("\t"+arrfi.getBussSeatsFare());
		System.out.println("\n");
			}
		System.out.println("Enter the Flight no");
		int fl_no=s.nextInt();
		FlightInformationDto details=fser.check_flight_no(fl_no);
		if(details!=null)
		{
		System.out.print("\t"+details.getAirline());
		System.out.print("\t"+details.getArr_city());
		System.out.print("\t"+details.getDep_city());
		System.out.print("\t"+details.getArr_date());
		System.out.print("\t"+details.getDep_date());
		System.out.print("\t"+details.getArr_time());
		System.out.print("\t"+details.getDep_time());
		System.out.print("\t"+details.getFirstSeats());
		System.out.print("\t"+details.getFirstSeatFare());
		System.out.print("\t"+details.getBussSeats());
		System.out.print("\t"+details.getBussSeatsFare());
		
		System.out.println("Enter the customer E-mail ID");
		String email=s.next();
		System.out.println("Enter the no. of passengers");
		no_passengers=s.nextInt();
		 if(no_passengers>0)
		 {
		System.out.println("Enter the Class Type");
		String class_type=s.next();
		class_type+=s.nextLine();	
		if(details.getAirline().toLowerCase().equals("air india"))
		{
			System.out.println(class_type.toLowerCase());
			if(class_type.toLowerCase().equals("first class"))
			{
				do
				{
					System.out.println("Enter the seat numbers('ALCT100 to ALCT180')");
					//check if seat no exists in already booked info  
					/*boolean seat_val=false;
					Scanner s=new Scanner(System.in);
					IBookingInfoService bser=new BookingInfoService();
					String seat_no_fin=null;*/
					int i;
					for(i=1;i<=no_passengers;i++)
					{
						seat_no[i]=s.next();//i/p
						String seat_no_single=seat_no[i];//cpy seat no as a single seat
						seat_val=bser.seat_availability_check(seat_no_single);//call the method
						seat_no_fin=seat_no_fin.concat(seat_no[i]);
						seat_no_fin=seat_no_fin.concat(",");
						String seat_no_final=seat_no_fin;
						if(seat_val==false)//returned value is false i.e if it is already booked
						{
							System.out.println("Please select another seat number.The seat you selected is not available");
							
						}//break;
						//return seat_val;
						//else if(seat_val!=false)
							//{
						else {
							System.out.println("seat added successfully");
						}}
							/*for(i=1;i<=no_passengers;i++)
							
						{
							seat_no_fin=seat_no_fin.concat(seat_no[i]);
							seat_no_fin=seat_no_fin.concat(",");
							}
							String seat_no_final=seat_no_fin;
							}*/
					/*seat_no_fin=seat(no_passengers,seat_no);//method call
					seat_number_final=seat_no_fin;*/
					//send it to db
				}while(seat_val==false);
				}else if(class_type.toLowerCase().equals("business class"))
			{
				do {
					System.out.println("Enter the seat numbers('ALCT181 to ALCT301')");
					seat(no_passengers,seat_no);
					seat_number_final=seat_no_fin;
				}while(seat_val==false);
				
			}else System.out.println("The entered class does not exists");
		}else if(details.getAirline().toLowerCase().equals("jet airways") || details.getAirline().toLowerCase().equals("air deccan"))
		{
			if(class_type.toLowerCase()=="first class")
			{
				do
				{
				
				System.out.println("Enter the seat numbers('ALCT200 to ALCT250')");
				seat(no_passengers,seat_no);
				seat_number_final=seat_no_fin;
				
			}while(seat_val==false);
			}else if(class_type.toLowerCase().equals("business class"))
			{
				do {
					System.out.println("Enter the seat numbers('ALCT251 to ALCT351')");
					seat(no_passengers,seat_no);
					 seat_number_final=seat_no_fin;
				}while(seat_val==false);
				
				
			}else System.out.println("The entered class does not exists");
		}else if(details.getAirline().toLowerCase().equals("indigo") || details.getAirline().toLowerCase().equals("spicejet") || details.getAirline().toLowerCase().equals("vistara"))
		{
			if(class_type.toLowerCase().equals("first class"))
			{
				do {
					System.out.println("Enter the seat numbers('ALCT500 to ALCT600')");
					seat(no_passengers,seat_no);
					 seat_number_final=seat_no_fin;
				}while(seat_val==false);
				
			}else if(class_type.toLowerCase().equals("business class"))
			{
				do {
				System.out.println("Enter the seat numbers('ALCT601 to ALCT701')");
				seat(no_passengers,seat_no);
				seat_number_final=seat_no_fin;
				}while(seat_val==false);
				
		}else System.out.println("The entered class does not exists");
		}
			else if(details.getAirline().toLowerCase().equals("truejet"))
		{
			if(class_type.toLowerCase().equals("first class"))
			{
				do {
				System.out.println("Enter the seat numbers('ALCT700 to ALCT820')");
				seat(no_passengers,seat_no);
				seat_number_final=seat_no_fin;
				}while(seat_val==false);
			}else if(class_type.toLowerCase().equals("business class"))
			{
				do {
				System.out.println("Enter the seat numbers('ALCT821 to ALCT921')");
				seat(no_passengers,seat_no);
				seat_number_final=seat_no_fin;
				}while(seat_val==false);
				  
		}else System.out.println("The entered class does not exists");
		
		
		System.out.println("Enter the credit card details");
		System.out.println("Enter the type of card");
		String type=s.next();
		System.out.println("Enter the name on the card");
		String user_name=s.next();
		System.out.println("Enter the credit card number");
		String credit_card=s.next();
		System.out.println("Enter the CVV number");
		int cvv=s.nextInt();
		System.out.println("Enter the date and year of expiry");
		int doe=s.nextInt();
		int yoe=s.nextInt();
		//concate the values not possible
		bid.setCust_email(email);
		bid.setNo_of_passengers(no_passengers);
		bid.setClass_type(class_type);
		//bid.setSeat_number(seat_number_final);
		bid.setSeat_number_final(seat_number_final);
		bid.setCreditCard_info(credit_card);
		bid.setCard_type(type);
		bid.setUser_name(user_name);
		bid.setCvv(cvv);
		bid.setDoe(doe);
		bid.setYoe(yoe);
		boolean result=bser.input_validation(bid);
		if(result==true)
		{
		int booking_id=bser.book_tickets(bid);
		if(booking_id>0)
		{
			double total_fare=bser.total_tickets_fare(bid,fid);
			System.out.println("Total fare of your ticket booked is: "+total_fare);
			fser.update_seats_available(no_passengers,fl_no,class_type);
		}
		
		
		//calculate total fare and return booking id 
		}else 
		{
			System.out.println("Please enter the valid data in all the fields");
		}
		}
		 }
		 else System.out.println("No of passengers cannot be zero");
		}else 
		{
			System.out.println("Sorry! the flight No you entered is not available");
		}
	}else
	{
		System.out.println("Sorry! flights not available for the source and destination you entered");
	}
			
	}
	public String seat(int no_passengers,String[] seat_no)
	{
		boolean seat_val=false;
		Scanner s=new Scanner(System.in);
		IBookingInfoService bser=new BookingInfoService();
		String seat_no_fin=null;
		int i;
		for(i=1;i<=no_passengers;i++)
		{
			seat_no[i]=s.next();
			String seat_no_single=seat_no[i];
			seat_val=bser.seat_availability_check(seat_no_single);
			if(seat_val==false)
			{
				System.out.println("Please select another seat number.The seat you selected is not available");
				
			}//break;
			//return seat_val;
			else if(seat_val!=false)
				{
				for(i=1;i<=no_passengers;i++)
				
			{
				seat_no_fin=seat_no_fin.concat(seat_no[i]);
				seat_no_fin=seat_no_fin.concat(",");
				}
				}
		}
		return seat_no_fin;
	}
	
	public static void main(String[] args) throws AirlineReservationException {
		main_pl mp=new main_pl();
		mp.main_menu();

	}

}
