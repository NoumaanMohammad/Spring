package com.cg.ars.dto;

public class AirportDto {
public String AirportName;
public String getAirportName() {
	return AirportName;
}
public void setAirportName(String airportName) {
	AirportName = airportName;
}
public String getAbbrevation() {
	return Abbrevation;
}
public void setAbbrevation(String abbrevation) {
	Abbrevation = abbrevation;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
public String Abbrevation;
public String Location;
}
