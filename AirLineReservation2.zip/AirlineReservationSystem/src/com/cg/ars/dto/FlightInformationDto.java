package com.cg.ars.dto;

import java.sql.Date;

public class FlightInformationDto {
	private int flightno; 
	public int getFlightno() {
		return flightno;
	}
	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDep_city() {
		return dep_city;
	}
	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}
	public String getArr_city() {
		return arr_city;
	}
	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}
	public Date getDep_date() {
		return dep_date;
	}
	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}
	public Date getArr_date() {
		return arr_date;
	}
	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}
	public String getDep_time() {
		return dep_time;
	}
	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}
	public String getArr_time() {
		return arr_time;
	}
	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}
	public int getFirstSeats() {
		return FirstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		FirstSeats = firstSeats;
	}
	public Double getFirstSeatFare() {
		return FirstSeatFare;
	}
	public void setFirstSeatFare(Double firstSeatFare) {
		FirstSeatFare = firstSeatFare;
	}
	public int getBussSeats() {
		return BussSeats;
	}
	public void setBussSeats(int bussSeats) {
		BussSeats = bussSeats;
	}
	public Double getBussSeatsFare() {
		return BussSeatsFare;
	}
	public void setBussSeatsFare(Double bussSeatsFare) {
		BussSeatsFare = bussSeatsFare;
	}
	private String airline; 
	 private String dep_city; 
	 private String arr_city; 
	 private Date dep_date; 
	 private Date arr_date; 
	 private String dep_time;
	 private String arr_time;
	 private int FirstSeats; 
	private Double FirstSeatFare; 
	 private int BussSeats; 
	 private Double BussSeatsFare; 
}

