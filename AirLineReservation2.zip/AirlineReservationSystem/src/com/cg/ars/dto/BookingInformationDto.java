package com.cg.ars.dto;

import java.sql.Date;

public class BookingInformationDto {
	private int Booking_id; 
	private String cust_email; 
	private int no_of_passengers; 
	private String class_type; 
	 private double total_fare;
	 private String seat_number;
	 public String getSeat_number() {
		return seat_number;
	}
	public void setSeat_number(String seat_number) {
		this.seat_number = seat_number;
	}
	
	private String seat_number_final;
	 public String getSeat_number_final() {
		return seat_number_final;
	}
	public void setSeat_number_final(String seat_number_final) {
		this.seat_number_final = seat_number_final;
	}

	private String CreditCard_info; 
	 private String card_type;
	 private String seat_no_single;
	 public String getSeat_no_single() {
		return seat_no_single;
	}
	public void setSeat_no_single(String seat_no_single) {
		this.seat_no_single = seat_no_single;
	}
	public String getCard_type() {
		return card_type;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	private String src_city; 
	 private String dest_city; 
	 private int flightno;
	 private  String user_name;
	 public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public int getYoe() {
		return yoe;
	}
	public int setYoe(int yoe) {
		return this.yoe = yoe;
	}
	public int getDoe() {
		return doe;
	}
	public int setDoe(int doe) {
		return this.doe = doe;
	}
	private int cvv;
	 private int yoe;
	 private int doe;
	public int getFlightno() {
		return flightno;
	}
	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}
	public int getBooking_id() {
		return Booking_id;
	}
	public int setBooking_id(int booking_id) {
		return Booking_id = booking_id;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	public int getNo_of_passengers() {
		return no_of_passengers;
	}
	public void setNo_of_passengers(int no_of_passengers) {
		this.no_of_passengers = no_of_passengers;
	}
	public String getClass_type() {
		return class_type;
	}
	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}
	public double getTotal_fare() {
		return total_fare;
	}
	public double setTotal_fare(double total_fare) {
		return this.total_fare = total_fare;
	}
	
	public String getCreditCard_info() {
		return CreditCard_info;
	}
	public void setCreditCard_info(String creditCard_info) {
		CreditCard_info = creditCard_info;
	}
	public String getSrc_city() {
		return src_city;
	}
	public void setSrc_city(String src_city) {
		this.src_city = src_city;
	}
	public String getDest_city() {
		return dest_city;
	}
	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}
	
	
}


