package com.cg.ars.test;

import org.junit.Test;

import com.cg.ars.dto.FlightInformationDto;

public class ExecutiveTestCase {

	@Test
	public void testBasedOnLocation(){
	
		FlightInformationDto dto=new FlightInformationDto();
		dto.setDep_city("Hyderabad");
		dto.setArr_city("Panaji");
	}
	
	
}
