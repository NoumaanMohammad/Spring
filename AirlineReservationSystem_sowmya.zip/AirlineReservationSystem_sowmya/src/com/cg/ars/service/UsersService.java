package com.cg.ars.service;

import com.cg.ars.dao.IUsersDao;
import com.cg.ars.dao.UsersImplDao;
import com.cg.ars.exception.UsersException;

public class UsersService implements IUsersService {

	

	IUsersDao dao;
	public UsersService() {
		dao=new UsersImplDao();
	}
	@Override
	public boolean isvalid(String username, String password)
			throws UsersException {
	
	return dao.isValid(username,password);
	}

}
