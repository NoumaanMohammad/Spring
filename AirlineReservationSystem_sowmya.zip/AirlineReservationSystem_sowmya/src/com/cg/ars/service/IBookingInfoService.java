package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.BookingInformationDto;

public interface IBookingInfoService {

}
