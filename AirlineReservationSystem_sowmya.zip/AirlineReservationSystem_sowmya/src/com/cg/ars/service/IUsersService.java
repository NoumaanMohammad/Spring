package com.cg.ars.service;

import com.cg.ars.exception.UsersException;

public interface IUsersService {

	public boolean isvalid(String username, String password)throws UsersException ;

}
