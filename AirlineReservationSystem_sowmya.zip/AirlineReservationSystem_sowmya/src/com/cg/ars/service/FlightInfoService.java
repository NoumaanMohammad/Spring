package com.cg.ars.service;


import java.time.LocalDate;
import java.util.List;

import com.cg.ars.dao.FlightImplDao;
import com.cg.ars.dao.IFlightInfoDao;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInfoException;


public class FlightInfoService implements IFlightInfoService {

	IFlightInfoDao dao;
	public FlightInfoService() {
		dao=new FlightImplDao();
	}
	@Override
	public List<FlightInformationDto> getFlightDetails(String dep_city,
			String arr_city) throws FlightInfoException {
		
		return dao.getFlightDetails(dep_city,arr_city);
	}
	@Override
	public List<FlightInformationDto> getFlightDetailsBasedOnDate(
			LocalDate dep_date, LocalDate arr_date) throws FlightInfoException {
		
		return dao.getFlightDetailsBasedOnDate(dep_date, arr_date);
	}
	

}
