package com.cg.ars.pl;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.dto.UsersDto;
import com.cg.ars.exception.FlightInfoException;
import com.cg.ars.exception.UsersException;
import com.cg.ars.service.FlightInfoService;
import com.cg.ars.service.IFlightInfoService;
import com.cg.ars.service.IUsersService;
import com.cg.ars.service.UsersService;


public class MainClass {
	
	
	static Logger lg=Logger.getLogger(MainClass.class);
	public static void main(String[] args) throws UsersException {
		
		PropertyConfigurator.configure("src/log4j.properties");
		
		Scanner sc=new Scanner(System.in);
		IUsersService userservice=new UsersService();
		IFlightInfoService flightservice=new FlightInfoService();
		
		UsersDto user= new UsersDto();
		
		System.out.println("");
		System.out.println("           Login Page        ");
		System.out.println("_________________________________");
		System.out.println("");
		System.out.println("USERNAME:");
		String username=sc.next();
        System.out.println("PASSWORD:");
		String password=sc.next();
		
		
		user.setUsername(username);
		user.setPassword(password);
		boolean res=userservice.isvalid(username,password);
		if(res==true){
			lg.info("Successfull Login by AirlineExecutive");
			System.out.println("Flight Occupancy Details");
			System.out.println("1.To view Flight Occupancy details based on location");
			System.out.println("2.To view Flight Occupancy details based on Date");
			System.out.println("Enter your choice:");
			int ch=sc.nextInt();
			switch(ch){
			
			case 1:
				lg.info("Executive is attempting to view flight occupancy details based on location");
				System.out.println("Enter Departure city:");
				String src_city=sc.next();
				System.out.println("Enter Destination Place:");
			
			    String dest_city=sc.next();
				
				List<FlightInformationDto> list;
				try {
					
					  list = flightservice.getFlightDetails(src_city,dest_city);
				
				    
				
				if(list.size()==0){
					
					System.out.println("Sorry no details found!!");
				}else{
					
					for( FlightInformationDto eb:list){
						
						System.out.println("Flight No:"+eb.getFlightNo()+"");
						
						System.out.println("Available Business Class Seats:"+eb.getBusSeats()+"");
						
						System.out.println("Available First Class Seats:"+eb.getFirstSeats()+"");
						
						int first=eb.getBusSeats();
						int Buss=eb.getFirstSeats();
						int total=first+Buss;
						System.out.println("Total Seats:"+total);
						System.out.println("");
						
					   }//for loop	
						
					
				    }//else loop
			     }//try block	
				
				catch (FlightInfoException e) {
						System.out.println(e.getMessage());
					}//catch block
				break;
			case 2:
				lg.info("Executive is attempting to view flight occupancy details based on date");
				System.out.println("Enter Departure Date:(dd-MMM-yyyy)");
				String de_date=sc.next();
				
				DateTimeFormatter formatter=
						DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				LocalDate dep_date=LocalDate.parse(de_date,formatter);
				
				//System.out.println(dep_date);
				
				System.out.println("Enter Arrival Date:");
				String ar_date=sc.next();
				
				LocalDate arr_date=LocalDate.parse(ar_date,formatter);
				
				
				//System.out.println(arr_date);
				
				
				List<FlightInformationDto> list2;
				try {
					
					  list2 = flightservice.getFlightDetailsBasedOnDate(dep_date,arr_date);
				
				    
				
				if(list2.size()==0){
					
					System.out.println("Sorry no details found for the particular time period !!! ");
				}else{
					
					for( FlightInformationDto eb:list2){
						
						System.out.println("Flight No:"+eb.getFlightNo()+"");
					
						System.out.println("Available Business Class Seats:"+eb.getBusSeats()+"");
						
						System.out.println("Available First Class Seats:"+eb.getFirstSeats()+"");
						int first=eb.getBusSeats();
						int Buss=eb.getFirstSeats();
						int total=first+Buss;
						System.out.println("Total Seats:"+total);
						System.out.println("");
					   }//for loop	
						
					
				    }//else loop
			     }//try block	
				
				catch (FlightInfoException e) {
						System.out.println(e.getMessage());
					}//catch block
				
			break;
				}//switch
			}//if(res==true)
		else{
			
			lg.info("Login Failed");
			System.out.println("Invalid Credentials!!");
			
		
	}//while loop
		
    }//main
}//class