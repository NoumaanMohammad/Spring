package com.cg.ars.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ars.pl.MainClass;

public class DatabaseConnection {

	public static Connection getConnection() {
	
	String url="";
	String username="";
	String pwd="";
	String driver="";
	Connection con=null;
	
	try {
		//externalize data
		InputStream in=new FileInputStream( "src/jdbc.properties");
		Properties pr=new Properties();
		pr.load(in);
		url=pr.getProperty("url");
		pwd=pr.getProperty("pwd");
		driver=pr.getProperty("driver");
		username=pr.getProperty("username");   //externalize data
		
		Class.forName(driver);
		con=DriverManager.getConnection(url,username,pwd);
		System.out.println("Database connected successfully");
		
	} catch (ClassNotFoundException e) {
		System.out.println("class no loaded");
	} catch (SQLException e) {
		System.out.println("Not connected with DB...");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return con;
	
	} // connection method
	public static void main(String[] args) {
		getConnection();
	}//main method
}//class closing
