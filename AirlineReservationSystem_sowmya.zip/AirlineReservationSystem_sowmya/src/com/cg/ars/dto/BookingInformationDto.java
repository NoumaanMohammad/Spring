package com.cg.ars.dto;

public class BookingInformationDto {

	int Booking_id;
	int flightno;
	String email;
	int no_of_passengers;
	String class_type;
	double total_fare;
	String seatNo;
	String creditinfo;
	String src_city;
	String dest_city;
	public int getBooking_id() {
		return Booking_id;
	}
	public void setBooking_id(int booking_id) {
		Booking_id = booking_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getNo_of_passengers() {
		return no_of_passengers;
	}
	public void setNo_of_passengers(int no_of_passengers) {
		this.no_of_passengers = no_of_passengers;
	}
	public String getClass_type() {
		return class_type;
	}
	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}
	public double getTotal_fare() {
		return total_fare;
	}
	public void setTotal_fare(double total_fare) {
		this.total_fare = total_fare;
	}
	public String getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}
	public String getCreditinfo() {
		return creditinfo;
	}
	public void setCreditinfo(String creditinfo) {
		this.creditinfo = creditinfo;
	}
	public String getSrc_city() {
		return src_city;
	}
	public void setSrc_city(String src_city) {
		this.src_city = src_city;
	}
	public String getDest_city() {
		return dest_city;
	}
	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}
	public int getFlightno() {
		return flightno;
	}
	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}
	
}
