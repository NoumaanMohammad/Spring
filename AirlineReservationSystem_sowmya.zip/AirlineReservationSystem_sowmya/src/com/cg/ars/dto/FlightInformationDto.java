package com.cg.ars.dto;

import java.sql.Date;

public class FlightInformationDto {

	int flightNo;
	String airline;
	String dep_city;
	String arr_city;
	Date dep_date;
	Date arr_date;
	String dept_time;
	String arr_time;
	int FirstSeats;
	double firstSeatFare;
	int BusSeats;
	double BusSeatsFare;
	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDep_city() {
		return dep_city;
	}
	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}
	public String getArr_city() {
		return arr_city;
	}
	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}
	public Date getDep_date() {
		return dep_date;
	}
	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}
	public Date getArr_date() {
		return arr_date;
	}
	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}
	public String getDept_time() {
		return dept_time;
	}
	public void setDept_time(String dept_time) {
		this.dept_time = dept_time;
	}
	public String getArr_time() {
		return arr_time;
	}
	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}
	public int getFirstSeats() {
		return FirstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		FirstSeats = firstSeats;
	}
	public double getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public int getBusSeats() {
		return BusSeats;
	}
	public void setBusSeats(int busSeats) {
		BusSeats = busSeats;
	}
	public double getBusSeatsFare() {
		return BusSeatsFare;
	}
	public void setBusSeatsFare(double busSeatsFare) {
		BusSeatsFare = busSeatsFare;
	}
	
}
