package com.cg.ars.dao;



public class BookingImpldao implements IBookingInfoDao{

	

}
