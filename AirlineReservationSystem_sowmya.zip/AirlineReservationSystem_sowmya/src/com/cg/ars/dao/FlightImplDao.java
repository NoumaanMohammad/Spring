package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInfoException;
import com.cg.ars.util.DatabaseConnection;

public class FlightImplDao implements IFlightInfoDao {

	@Override
	public List<FlightInformationDto> getFlightDetails(String dep_city,
			String arr_city) throws FlightInfoException {
		List<FlightInformationDto> list=new ArrayList<FlightInformationDto>();
		String sql="SELECT flightno,firstseats,bussseats FROM FlightInformation where dep_city=? and arr_city=?";
		
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dep_city);
			ps.setString(2, arr_city);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				
				FlightInformationDto fn=new FlightInformationDto();
				
				int flightno=rs.getInt("flightno");
				
				int firstSeats=rs.getInt("firstseats");
				
				int bussseats=rs.getInt("bussseats");
				
				fn.setFlightNo(flightno);
			    fn.setFirstSeats(firstSeats);
				
				fn.setBusSeats(bussseats);
				
				
				list.add(fn);
			}
		} catch (SQLException e) {
		
			throw new FlightInfoException();
		}
		
		return list;
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsBasedOnDate(
			LocalDate dep_date, LocalDate arr_date) throws FlightInfoException {
		
		List<FlightInformationDto> list=new ArrayList<FlightInformationDto>();
		String sql="SELECT flightno,firstseats,bussseats FROM FlightInformation where dep_date=? and arr_date=?";
		
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			Date de_date=Date.valueOf(dep_date);
			ps.setDate(1, de_date);
			Date ar_date=Date.valueOf(arr_date);
			ps.setDate(2, ar_date);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				
				FlightInformationDto fn=new FlightInformationDto();
				int  flightno=rs.getInt("flightno");
				int firstSeats=rs.getInt("firstseats");
				
				int bussseats=rs.getInt("bussseats");
				
				fn.setFlightNo(flightno);
			    fn.setFirstSeats(firstSeats);
				
				fn.setBusSeats(bussseats);
				
				
				list.add(fn);
			}
		} catch (SQLException e) {
		
			throw new FlightInfoException();
		}
		
		return list;
		
	}

}
