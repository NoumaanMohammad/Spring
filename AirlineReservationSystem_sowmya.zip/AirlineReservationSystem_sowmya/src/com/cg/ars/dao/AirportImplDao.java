package com.cg.ars.dao;

public class AirportImplDao implements IAirportDao{

}
