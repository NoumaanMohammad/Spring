package com.cg.ars.dao;



import com.cg.ars.exception.UsersException;

public interface IUsersDao {

     public boolean isValid(String username, String password)throws UsersException;

	

	

}
