package com.cg.ars.dao;


import java.time.LocalDate;
import java.util.List;

import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInfoException;

public interface IFlightInfoDao {

	public List<FlightInformationDto> getFlightDetails(String dep_city, String arr_city) throws FlightInfoException ;

	public List<FlightInformationDto> getFlightDetailsBasedOnDate(
			LocalDate dep_date, LocalDate arr_date) throws FlightInfoException;
	
}
