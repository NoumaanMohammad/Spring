package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.ars.exception.UsersException;
import com.cg.ars.util.DatabaseConnection;



public class UsersImplDao implements IUsersDao{

	@Override
	public boolean isValid(String username, String password)
			throws UsersException {
		
		String sql="SELECT * FROM users WHERE role='Executive' AND username=? AND password=?";
		//UsersDto dto=null;
		boolean validation=false;
		
		try {
			Connection con=DatabaseConnection.getConnection();
			PreparedStatement s=con.prepareStatement(sql);
			
			s.setString(1, username);
			s.setString(2, password);
			
			ResultSet rs=s.executeQuery();
			//System.out.println(rs.next());
			while(rs.next()){
				validation=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			validation=false;
		}
		return validation;
	}

	}
