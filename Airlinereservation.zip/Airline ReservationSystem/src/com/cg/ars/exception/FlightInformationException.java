package com.cg.ars.exception;

public class FlightInformationException extends ReservationException{
	
	public FlightInformationException(String msg) {
		super(msg);
	}

}
