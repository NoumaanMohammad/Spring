package com.cg.ars.service;

import com.cg.ars.dao.UsersDaoImpl;
import com.cg.ars.dto.UsersDto;
import com.cg.ars.exception.UsersException;

public class UsersServiceImpl implements UsersService{
	
	UsersDaoImpl dao=new UsersDaoImpl();


	public boolean validateCredentials(String username,String password) throws UsersException {
		
		return dao.validateCredentials(username,password);
	} 
	
	

}
