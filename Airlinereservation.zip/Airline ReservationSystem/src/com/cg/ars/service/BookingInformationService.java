package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;

public interface BookingInformationService {
	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException;
	public List<BookingInformationDto> getPassengersListofFlight(int flightNo) throws ReservationException;

	//anagha
	public BookingInformationDto getBookingDetailsForUser(int bookId) throws ReservationException;
	public int cancelBookingDetailsForUser(BookingInformationDto book) throws ReservationException;
	public int bookTicketForUser(BookingInformationDto dto) throws ReservationException;
	public int sequenceForSeatNumber() throws FlightInformationException;
	public int updateTicketDEtailsforUser(BookingInformationDto dto) throws FlightInformationException;



}
