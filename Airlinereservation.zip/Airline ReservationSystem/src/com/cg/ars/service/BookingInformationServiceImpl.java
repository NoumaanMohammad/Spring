package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dao.BookingInformationDao;
import com.cg.ars.dao.BookingInformationDaoImpl;
import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;

public class BookingInformationServiceImpl implements BookingInformationService {

	BookingInformationDao dao=new BookingInformationDaoImpl();
	@Override
	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException {
		return dao.getBookingDetails(flightNo);
	}
	@Override
	public List<BookingInformationDto> getPassengersListofFlight(int flightNo)
			throws ReservationException {
		return dao.getPassengerList(flightNo);
	}
	@Override
	public BookingInformationDto getBookingDetailsForUser(int bookId) throws ReservationException {
		return dao.getBookingDetailsForUser(bookId);
	}
	@Override
	public int cancelBookingDetailsForUser(BookingInformationDto book) throws ReservationException {
		return dao.cancelBookingDetailsForUser(book);
	}
	@Override
	public int bookTicketForUser(BookingInformationDto dto) throws ReservationException {
		return dao.bookTicketForUser(dto);
	}
	@Override
	public int sequenceForSeatNumber() throws FlightInformationException {
		return dao.sequenceForSeatNumber();
	}
	@Override
	public int updateTicketDEtailsforUser(BookingInformationDto dto) throws FlightInformationException {
		return dao.updateTicketDEtailsforUser(dto);
	}

}
