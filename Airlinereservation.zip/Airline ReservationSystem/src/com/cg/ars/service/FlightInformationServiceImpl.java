package com.cg.ars.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.ars.dao.FlightInformationDaoImpl;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;

public class FlightInformationServiceImpl implements FlightInformationService {
	
	FlightInformationDaoImpl dao=new FlightInformationDaoImpl();
	
	@Override
	public List<FlightInformationDto> getFlightDetailsbyAirlineName(
			String Airline) throws FlightInformationException {
		String airLine="";
		if(Airline.equalsIgnoreCase("jetairways")||Airline.equalsIgnoreCase("airindia")||Airline.equalsIgnoreCase("airdeccan"))
		{
			airLine=Airline.substring(0, 3)+" "+Airline.substring(3);
			
		}
		else airLine=Airline;
		
		return dao.getFlightDetailsbyAirlineName(airLine);
		
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsbyDestCity(
			String destCity) throws FlightInformationException {

		return dao.getFlightDetailsbyDestCity(destCity);
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsbyDate(
			LocalDate ldate) throws FlightInformationException {
		
		return dao.getFlightDetailsbyDate(ldate);
	}

	@Override
	public int updateFlightSchedule(FlightInformationDto flight)
			throws FlightInformationException {
		return dao.updateFlightSchedule(flight);
	}

	@Override
	public int addNewFlightDetails(FlightInformationDto flight)
			throws FlightInformationException {
		return dao.addNewFlightDetails(flight);
	}

	@Override
	public int updateFareDetails(int flightNo, double busFare, double FirstFare)
			throws FlightInformationException {
		return dao.updateFareDetails(flightNo, busFare, FirstFare);
		
	}

	@Override
	public int updateCityDetails(int flightNo, String deCity, String arrCity)
			throws FlightInformationException {
		return dao.updateCityDetails(flightNo, deCity, arrCity);
		
	}

	@Override
	public List<FlightInformationDto> getAllFlightDetails()
			throws FlightInformationException {
		return dao.getAllFlightDetails();
	}

	@Override
	public FlightInformationDto getFlightDetailsbyFlightNo(int flightNo) throws FlightInformationException {
		return dao.getFlightDetailsbyFlightNo(flightNo);
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsByCities(String srcCity, String destCity)
			throws FlightInformationException {
		return dao.getFlightDetailsByCities(srcCity, destCity);
	}

}
