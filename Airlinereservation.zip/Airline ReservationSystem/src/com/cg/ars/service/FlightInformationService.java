package com.cg.ars.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;

public interface FlightInformationService {

	public List<FlightInformationDto> getFlightDetailsbyAirlineName(String Airline) throws ReservationException;
	public List<FlightInformationDto> getFlightDetailsbyDestCity(String destCity) throws ReservationException;
	public List<FlightInformationDto> getFlightDetailsbyDate(LocalDate ldate) throws ReservationException;
	public int updateFlightSchedule(FlightInformationDto flight) throws FlightInformationException;
	public int addNewFlightDetails(FlightInformationDto flight) throws FlightInformationException;
	public int updateFareDetails(int flightNo,double busFare,double FirstFare)  throws FlightInformationException;
	public int updateCityDetails(int flightNo,String deCity,String arrCity) throws FlightInformationException;
	public List<FlightInformationDto> getAllFlightDetails() throws FlightInformationException;

	
	//anagha
	public FlightInformationDto getFlightDetailsbyFlightNo(int flightNo) throws FlightInformationException;
	public List<FlightInformationDto> getFlightDetailsByCities(String srcCity,String destCity) throws FlightInformationException;

}
