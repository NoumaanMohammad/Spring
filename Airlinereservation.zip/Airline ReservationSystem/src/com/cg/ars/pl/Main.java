package com.cg.ars.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;
import com.cg.ars.exception.UsersException;
import com.cg.ars.service.BookingInformationService;
import com.cg.ars.service.BookingInformationServiceImpl;
import com.cg.ars.service.FlightInformationService;
import com.cg.ars.service.FlightInformationServiceImpl;
import com.cg.ars.service.UsersServiceImpl;

public class Main {
		
	static Logger lg=Logger.getLogger(Main.class);

	
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
	
	
	public static void main(String[] args) throws IOException {
		
		PropertyConfigurator.configure("./resources/log4j.properties");
		
		System.out.println("********************************Airline Reservation System***********************************");
		
		while(true) {
		
		System.out.println("1.Admin\n2.Airline executive\n3.User\n4.Exit\n*****************************************************");
		System.out.println("Enter your role to proceed");

		int mainChoice=Integer.parseInt(br.readLine());

		switch(mainChoice) {
		
		case 1:
			adminModule();
			break;
			
		case 2:
			
			
			
		case 3:
			userModule();
			break;
			
			
		case 4:
			System.exit(0);
			
		}
		
		}//while
		
	}//main
	
	
	
	private static void userModule() {
		
		userMenu:while(true) {
			try {
			System.out.println("\n1.Book a flight ticket");
			System.out.println("2.View a booked flight ticket");
			System.out.println("3.Update the flight ticket details");
			System.out.println("4.Cancel the flight ticket");
			System.out.println("5.Back to main menu");
			System.out.println("Input the choice");
			
				int choice=Integer.parseInt(br.readLine());
				switch(choice) {
					
				case 1:
					bookFlightTicketForUser();
					break;
					
					
				case 2:
					viewBookedFlightDetailsForUser();
					break;
					
				case 3:
					updateBookingForUser();
					break;
					
				case 4:
					cancelBookingForUser();
					break;
					
				case 5:
					break userMenu;
				
				}
			} catch (NumberFormatException | IOException e) {
				System.out.println("Check the given input");
			}
			
		}
	}



	private static void updateBookingForUser() {
		try {
		System.out.println("Enter booking id to change details");
			int bookId=Integer.parseInt(br.readLine());
			
			BookingInformationService service=new BookingInformationServiceImpl();
			FlightInformationService fservice=new FlightInformationServiceImpl();
			
			try {
				BookingInformationDto book=service.getBookingDetailsForUser(bookId);
				System.out.println("\nBooking Id: "+book.getBookingId());
				System.out.println("Flight Number: "+book.getFlightno());
				System.out.println("Customer Email: "+book.getEmail());
				System.out.println("Number of Passengers: "+book.getPassengers());
				System.out.println("CLass Type: "+book.getClassType());
				System.out.println("Total Fare: "+book.getTotalFare());
				System.out.println("Seat Numbers: "+book.getSeatNumber());
				System.out.println("Creditcard Info: "+book.getCreditCardInfo());
				System.out.println("Source City: "+book.getSourceCity());
				System.out.println("Destination City: "+book.getDestCity());
				
				System.out.println("Enter Source city");
				String srcCity=br.readLine();
				
				System.out.println("Enter Destination City");
				String destCity=br.readLine();
				
				List<FlightInformationDto> list=fservice.getFlightDetailsByCities(srcCity, destCity);
				
				if(list.size()==0) {
					System.out.println("There are no flights with the given cities ");
					return ;
				}
				else
			
				for(FlightInformationDto list1:list) {
					System.out.println("\n\nFLight Number:  "+list1.getFlightNo());
					System.out.println("Airline:  "+list1.getAirLine());
					System.out.println("Departure City:  "+list1.getDep_City());
					System.out.println("Arrival City:  "+list1.getArr_City());
					System.out.println("Departure Date:  "+list1.getDep_Date());
					System.out.println("Arrival Date:  "+list1.getArr_Date());
					System.out.println("Departure Time(HH:mm):  "+list1.getDep_Time());
					System.out.println("Arrival Time(HH:mm):  "+list1.getArr_Time());
					System.out.println("Firstclass Seats:  "+list1.getFirstSeats());
					System.out.println("Firstclass Seatfare:  "+list1.getFirstSeatFare());
					System.out.println("Business class Seats:  "+list1.getBussSeats());
					System.out.println("Business class Seatfare:  "+list1.getBussSeatsFare());
					
				}
				System.out.println("\n Enter flight number from above flights list");
				int flightNo=Integer.parseInt(br.readLine());
				
				FlightInformationDto dto1=fservice.getFlightDetailsbyFlightNo(flightNo);
				if(dto1.equals(null)) {
					System.out.println("you have not selected from the given flights list");
					return ;
				}
				System.out.println("\n\nFLight Number:  "+dto1.getFlightNo());
				System.out.println("Airline:  "+dto1.getAirLine());
				System.out.println("Departure City:  "+dto1.getDep_City());
				System.out.println("Arrival City:  "+dto1.getArr_City());
				System.out.println("Departure Date:  "+dto1.getDep_Date());
				System.out.println("Arrival Date:  "+dto1.getArr_Date());
				System.out.println("Departure Time(HH:mm):  "+dto1.getDep_Time());
				System.out.println("Arrival Time(HH:mm):  "+dto1.getArr_Time());
				System.out.println("Firstclass Seats:  "+dto1.getFirstSeats());
				System.out.println("Firstclass Seatfare:  "+dto1.getFirstSeatFare());
				System.out.println("Business class Seats:  "+dto1.getBussSeats());
				System.out.println("Business class Seatfare:  "+dto1.getBussSeatsFare());
				
				
				System.out.println("Enter Email Id");
				String mail=br.readLine();
				
				System.out.println("Enter no of passengers");
				int passengers=Integer.parseInt(br.readLine());
				
				System.out.println("Enter class type Business or First");
				String classType=br.readLine();
				
				System.out.println("Enter creditcard info (16digitnumber,name,cvv,expiry month/date) format");
				String creditCardInfo=br.readLine();
				
				double totalFare=0;
				if((classType.toLowerCase()).contains("first")) {
					totalFare=dto1.getFirstSeatFare()*passengers;
				} else if((classType.toLowerCase()).contains("bus")) {
					totalFare=dto1.getBussSeatsFare()*passengers;

				}
				String seatNumber="";
				String seat=dto1.getAirLine().substring(0, 2)+classType.substring(0, 1);
				for(int i=0;i<passengers;i++) {
					int number=service.sequenceForSeatNumber();
					seatNumber=seatNumber.concat(seat+""+number+",");

				}
				System.out.println(seatNumber);
				BookingInformationDto dto=new BookingInformationDto();
				dto.setFlightno(flightNo);
				dto.setEmail(mail);
				dto.setPassengers(passengers);
				dto.setClassType(classType);
				dto.setCreditCardInfo(creditCardInfo);
				dto.setSourceCity(srcCity);
				dto.setDestCity(destCity);
				dto.setTotalFare(totalFare);
				dto.setSeatNumber(seatNumber);
				int result=0;
				result=service.updateTicketDEtailsforUser(dto);
				if(result!=0) {
					System.out.println("Updated successfully");
				}
				
			} catch (ReservationException e) {
				System.out.println("Error Occured "+e.getMessage());
			}
		} catch (NumberFormatException | IOException e) {
			System.out.println("check the given data");
		}
	}



	private static void bookFlightTicketForUser() {
		FlightInformationService service=new FlightInformationServiceImpl();
		BookingInformationService service2=new BookingInformationServiceImpl();
		try {
		System.out.println("Enter Source city");
		String srcCity=br.readLine();
		
		System.out.println("Enter Destination City");
		String destCity=br.readLine();
		
		try {
			List<FlightInformationDto> list=service.getFlightDetailsByCities(srcCity, destCity);
			
			if(list.size()==0) {
				System.out.println("There are no flights with the given cities ");
				return ;
			}
			else
		
			for(FlightInformationDto list1:list) {
				System.out.println("\n\nFLight Number:  "+list1.getFlightNo());
				System.out.println("Airline:  "+list1.getAirLine());
				System.out.println("Departure City:  "+list1.getDep_City());
				System.out.println("Arrival City:  "+list1.getArr_City());
				System.out.println("Departure Date:  "+list1.getDep_Date());
				System.out.println("Arrival Date:  "+list1.getArr_Date());
				System.out.println("Departure Time(HH:mm):  "+list1.getDep_Time());
				System.out.println("Arrival Time(HH:mm):  "+list1.getArr_Time());
				System.out.println("Firstclass Seats:  "+list1.getFirstSeats());
				System.out.println("Firstclass Seatfare:  "+list1.getFirstSeatFare());
				System.out.println("Business class Seats:  "+list1.getBussSeats());
				System.out.println("Business class Seatfare:  "+list1.getBussSeatsFare());
				
			}
			System.out.println("\n Enter flight number from above flights list");
			int flightNo=Integer.parseInt(br.readLine());
			
			FlightInformationDto dto1=service.getFlightDetailsbyFlightNo(flightNo);
			if(dto1.equals(null)) {
				System.out.println("you have not selected from the given flights list");
				return ;
			}
			System.out.println("\n\nFLight Number:  "+dto1.getFlightNo());
			System.out.println("Airline:  "+dto1.getAirLine());
			System.out.println("Departure City:  "+dto1.getDep_City());
			System.out.println("Arrival City:  "+dto1.getArr_City());
			System.out.println("Departure Date:  "+dto1.getDep_Date());
			System.out.println("Arrival Date:  "+dto1.getArr_Date());
			System.out.println("Departure Time(HH:mm):  "+dto1.getDep_Time());
			System.out.println("Arrival Time(HH:mm):  "+dto1.getArr_Time());
			System.out.println("Firstclass Seats:  "+dto1.getFirstSeats());
			System.out.println("Firstclass Seatfare:  "+dto1.getFirstSeatFare());
			System.out.println("Business class Seats:  "+dto1.getBussSeats());
			System.out.println("Business class Seatfare:  "+dto1.getBussSeatsFare());
			
			
			System.out.println("Enter Email Id");
			String mail=br.readLine();
			
			System.out.println("Enter no of passengers");
			int passengers=Integer.parseInt(br.readLine());
			
			System.out.println("Enter class type Business or First");
			String classType=br.readLine();
			
			System.out.println("Enter creditcard info (16digitnumber,name,cvv,expiry month/date) format");
			String creditCardInfo=br.readLine();
			
			double totalFare=0;
			if((classType.toLowerCase()).contains("first")) {
				totalFare=dto1.getFirstSeatFare()*passengers;
			} else if((classType.toLowerCase()).contains("bus")) {
				totalFare=dto1.getBussSeatsFare()*passengers;

			}
			String seatNumber="";
			String seat=dto1.getAirLine().substring(0, 2)+classType.substring(0, 1);
			for(int i=0;i<passengers;i++) {
				int number=service2.sequenceForSeatNumber();
				seatNumber=seatNumber.concat(seat+""+number+",");

			}
			System.out.println(seatNumber);
			BookingInformationDto dto=new BookingInformationDto();
			dto.setFlightno(flightNo);
			dto.setEmail(mail);
			dto.setPassengers(passengers);
			dto.setClassType(classType);
			dto.setCreditCardInfo(creditCardInfo);
			dto.setSourceCity(srcCity);
			dto.setDestCity(destCity);
			dto.setTotalFare(totalFare);
			dto.setSeatNumber(seatNumber);
			try {
				System.out.println("hii");
				int id=service2.bookTicketForUser(dto);
				BookingInformationDto booking=service2.getBookingDetailsForUser(id);
				System.out.println("your ticket details are\n");
				System.out.println("\nBooking Id: "+booking.getBookingId());
				System.out.println("Flight Number: "+booking.getFlightno());
				System.out.println("Customer Email: "+booking.getEmail());
				System.out.println("Number of Passengers: "+booking.getPassengers());
				System.out.println("CLass Type: "+booking.getClassType());
				System.out.println("Total Fare: "+booking.getTotalFare());
				System.out.println("Seat Numbers: "+booking.getSeatNumber());
				System.out.println("Creditcard Info: "+booking.getCreditCardInfo());
				System.out.println("Source City: "+booking.getSourceCity());
				System.out.println("Destination City: "+booking.getDestCity());
				
			} catch (ReservationException e) {
				System.out.println("Error Occured "+e.getMessage());
			}
			
			
		} catch (FlightInformationException e) {
			System.out.println("Error "+e.getMessage() );
		}
		
		} catch (IOException e) {
			System.out.println("Check the given data");
		}
	}



	private static void cancelBookingForUser() {
			
		try {
		System.out.println("Enter booking id for cancellation");
			int bookId=Integer.parseInt(br.readLine());
				
			BookingInformationService service=new BookingInformationServiceImpl();
			FlightInformationService flightService=new FlightInformationServiceImpl();
			int status=0;
			try {
				BookingInformationDto book=service.getBookingDetailsForUser(bookId);
				
				System.out.println("\nBooking Id: "+book.getBookingId());
				System.out.println("Flight Number: "+book.getFlightno());
				System.out.println("Customer Email: "+book.getEmail());
				System.out.println("Number of Passengers: "+book.getPassengers());
				System.out.println("CLass Type: "+book.getClassType());
				System.out.println("Total Fare: "+book.getTotalFare());
				System.out.println("Seat Numbers: "+book.getSeatNumber());
				System.out.println("Creditcard Info: "+book.getCreditCardInfo());
				System.out.println("Source City: "+book.getSourceCity());
				System.out.println("Destination City: "+book.getDestCity());
				
				System.out.println("\nPress 1 to delete");
				int delete=Integer.parseInt(br.readLine());
				if(delete!=1) {
					System.out.println("Booking not deleted");
					return ;
				} 
				//FlightInformationDto flight=flightService.getFlightDetailsbyFlightNo(book.getFlightno());
				status=service.cancelBookingDetailsForUser(book);
				
				if(status!=0) {
					System.out.println("Ticket cancelled successfully");
				}
					
				
			} catch (ReservationException e) {
				System.out.println("Error occured "+e.getMessage());
			}
					
			
		} catch (NumberFormatException | IOException e) {
			System.out.println("Check the given data");
		}
		
	}



	private static void viewBookedFlightDetailsForUser() {
		try {
		System.out.println("enter booking id to view the ticket details");
		int ticketId=Integer.parseInt(br.readLine());
		BookingInformationService service=new BookingInformationServiceImpl();
		
		try {
			BookingInformationDto book=service.getBookingDetailsForUser(ticketId);
			
			System.out.println("\nBooking Id: "+book.getBookingId());
			System.out.println("Flight Number: "+book.getFlightno());
			System.out.println("Customer Email: "+book.getEmail());
			System.out.println("Number of Passengers: "+book.getPassengers());
			System.out.println("CLass Type: "+book.getClassType());
			System.out.println("Total Fare: "+book.getTotalFare());
			System.out.println("Seat Numbers: "+book.getSeatNumber());
			System.out.println("Creditcard Info: "+book.getCreditCardInfo());
			System.out.println("Source City: "+book.getSourceCity());
			System.out.println("Destination City: "+book.getDestCity());
		} catch (ReservationException e) {
			System.out.println("Error occured "+e.getMessage());
		}
				
		} catch (NumberFormatException | IOException e) {
			System.out.println("Check the given data");
		}
	}



	public static void adminModule() throws NumberFormatException, IOException {
		

		boolean validation = false;

		authentication:while(true) {
			
			System.out.println("\n1.login\n"
					+ "2.back\n\n"
					+ "Enter your choice\n");
			
			int Login=Integer.parseInt(br.readLine());
			if(Login==2) {
				break authentication; 
			}

			validation=authentication();
			
			if(!validation) 
			{
				System.out.println("UserName or Password is Incorrect!!");
			}
			else break;
		
		}
			if(validation)
			
			{
				System.out.println("Login Successful\n");
				
				menu:while(true) {
					
				
				System.out.println("\n\n1.Update and Manage Flight Info\n"
						+ "2.view list of flights of particular date,airline,source city etc\n"
						+ "3.Logout\n\n"
						+ "Enter your choice\n");
				int choice=Integer.parseInt(br.readLine());

				
				switch(choice) {
				
				case 1:
					updateOrManage();
					break;
					
				
				case 2:
					view();
					break;
					
				
				case 3:
					break menu;
					
				
				
				} //switch
				
				}//while
				
				
			} //if true
				
	}
	
	
	
	
	
	private static void updateOrManage() {
		update:while(true) {
		try {
		System.out.println("\n1.Add new FLight details\n"
				+ "2.update and manage flight schedule\n"
				+ "3.update fares of a particular flight\n"
				+ "4.update source and destination cities of particular flight\n"
				+ "5.go to previous menu\n\n"
				+ "Enter your choice");
		
			int choice=Integer.parseInt(br.readLine());
			
			switch(choice) {
			
				case 1:
					addFlightDetails();
					break;
					
			
				case 2:
					updateFlightSchedule();
					break;
					
				case 3:
					updateFareDetails();
					break;
					
				case 4:
					updateCities();
					break;
					
				case 5:
					break update;
					
			}
		} catch (NumberFormatException e) {
			System.out.println("Please check the given data!!");
		} catch (IOException e) {
			System.out.println("Please check the given data!!");

		}
		}
		
	}








	private static void updateCities() {
		int result=0;
		try {
		
		System.out.println("Enter flight number to update source and destination cities");
		int flightNum=Integer.parseInt(br.readLine());
		
		System.out.println("Enter Departure City");
		String depCity=br.readLine();
		
		System.out.println("Enter Arrival City");
		String arrCity=br.readLine();
		
		FlightInformationService service=new FlightInformationServiceImpl();
		
		try {
		 result=service.updateCityDetails(flightNum, depCity, arrCity);
		 if(result==0) {
			 System.out.println("Updation failed");
		 }
		 else System.out.println("Updation completed succesfully");
		} catch (FlightInformationException e) {
			System.out.println("Error Occured "+e.getMessage());
		}
				
		} catch (NumberFormatException | IOException e) {
			System.out.println("Check the given input");
			
		}
		
	}








	private static void updateFareDetails() {
		try {
		System.out.println("Enter flight number to update fare details");
		int flightNo=Integer.parseInt(br.readLine());
		
		System.out.println("Enter the fare for Firstclass");
		double firstClassFare=Double.parseDouble(br.readLine());
		
		System.out.println("Enter the fare for business class");
		double busSeatsFare=Double.parseDouble(br.readLine());
			
			if(firstClassFare<1||busSeatsFare<1||flightNo<1) {
				System.out.println("Fare details or Flight number should not be less than zero");
				return ;
			}
			FlightInformationService service=new FlightInformationServiceImpl();
			int result=0;
			try {
				result = service.updateFareDetails(flightNo, busSeatsFare, firstClassFare);
			} catch (FlightInformationException e) {
				System.out.println("Error Occured "+e.getMessage());
			}
			if(result==0) {
				System.out.println("Flight Information Updation failed");
			} else
			System.out.println("Fares updated successfully");
		} catch (NumberFormatException | IOException e) {
			System.out.println("Please check the given data");
		}
		
	}








	private static void addFlightDetails() {
		try {
			System.out.println("Enter flight number");
			int flightNum=Integer.parseInt(br.readLine());
			
			System.out.println("Enter airline name");
			String airLine=br.readLine();
			
			System.out.println("Enter departure city");
			String depCity=br.readLine();
			
			System.out.println("Enter arrival city");
			String arrCity=br.readLine();
			
			System.out.println("Enter depaarture date(dd-MM-yyyy)");
			String date1=br.readLine();
	
			System.out.println("Enter Arrival date(dd-MM-yyyy)");
			String date2=br.readLine();
			
			System.out.println("Enter departure time(HH:mm)");
			String depT=br.readLine();
			
			System.out.println("Enter arrival time(HH:mm)");
			String arrT=br.readLine();
			
			String arrival=date2+" "+arrT;
			String departure=date1+" "+depT;
			DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
			LocalDateTime arrivalDateAndTime=LocalDateTime.parse(arrival, format);
			LocalDateTime departureDateAndTime=LocalDateTime.parse(departure, format);
			
				if(arrivalDateAndTime.isBefore(departureDateAndTime)) {
					System.out.println("\nArival Date or time values should not be less than departure's date or time");
					return ;
				}
				
				DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate depDate1=LocalDate.parse(date1, formatter);
				LocalDate arrDate1=LocalDate.parse(date2, formatter);
				
			System.out.println("Enter the total no of First class seats");
			int firstSeats=Integer.parseInt(br.readLine());
			
			System.out.println("Enter fare for the first class seats");
			double firstSeatsFare=Double.parseDouble(br.readLine());
			
			System.out.println("Enter total no of Business class seats");
			int busSeats=Integer.parseInt(br.readLine());
			
			System.out.println("Enter fare for the business class seats");
			double busSeatsFare=Double.parseDouble(br.readLine());
			FlightInformationDto flight=new FlightInformationDto();
			
			flight.setFlightNo(flightNum);
			flight.setAirLine(airLine);
			flight.setDep_City(depCity);
			flight.setArr_City(arrCity);
			flight.setDep_Date(depDate1);
			flight.setArr_Date(arrDate1);
			flight.setDep_Time(depT);
			flight.setArr_Time(arrT);
			flight.setFirstSeats(firstSeats);
			flight.setFirstSeatFare(firstSeatsFare);
			flight.setBussSeats(busSeats);
			flight.setBussSeatsFare(busSeatsFare);
			
			FlightInformationService service=new FlightInformationServiceImpl();
			try {
				int rows=service.addNewFlightDetails(flight);
				if(rows==0) {
					System.out.println("\nFailed to insert data");
				}
				System.out.println("Data inserted Succesfully");
			} catch (FlightInformationException e) {
				System.out.println("Error Occured "+e.getMessage());
			}
			

		} catch (NumberFormatException | IOException e) {
			System.out.println("please check the given input");
		}
	}








	private static void updateFlightSchedule() {
		try {
		System.out.println("Enter flight number to update flight schedule");
			int flightNum=Integer.parseInt(br.readLine());
			
			System.out.println("Enter updated depaarture date(dd-MM-yyyy)");
			String date1=br.readLine();
			
			
			System.out.println("Enter updated Arrival date(dd-MM-yyyy)");
			String date2=br.readLine();
			
			System.out.println("Enter departure time(HH:mm)");
			String depT=br.readLine();
			
			System.out.println("Enter arrival time(HH:mm)");
			String arrT=br.readLine();
			
		
			
			
			FlightInformationServiceImpl service=new FlightInformationServiceImpl();   //FlightInformationServiceImpl object

			
			String arrival=date2+" "+arrT;
			String departure=date1+" "+depT;
			DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
			LocalDateTime arrivalDateAndTime=LocalDateTime.parse(arrival, format);
			LocalDateTime departureDateAndTime=LocalDateTime.parse(departure, format);
				if(arrivalDateAndTime.isBefore(departureDateAndTime)) {
					System.out.println("\nArival Date or time values should not be less than departure's date or time");
					return ;
				}
				
				DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate depDate1=LocalDate.parse(date1, formatter);
				LocalDate arrDate1=LocalDate.parse(date2, formatter);

				FlightInformationDto flight=new FlightInformationDto();
				flight.setFlightNo(flightNum);
				flight.setDep_Date(depDate1);
				flight.setArr_Date(arrDate1);
				flight.setDep_Time(depT);
				flight.setArr_Time(arrT);
			
			try {
				int status=service.updateFlightSchedule(flight);
				if(status==1) {
					System.out.println("\nData updated succesfully");
				}
			} catch (FlightInformationException e) {
				System.out.println("Error Occured: "+e.getMessage());
			}
			
		} catch (IOException e) {
			System.out.println("Please check the given input!!");
		}
		
	}








	private static void view()  {
		
		
		view:while(true) {

		System.out.println("\n\n1.view list of flights of a particular airlines\n"
				+ "2.view List of flights particular destination\n"
				+ "3.view List of flights on particular day\n"
				+ "4.view bookings of specific flight\n"
				+ "5.view Passenger list of specific flight\n"
				+ "6.goto previous menu\n\n"
				+ "Enter your choice\n");
		
		int choice;
		try {
			choice = Integer.parseInt(br.readLine());
		
		
		
		switch(choice) {
		
				case 1:
					flightListbyAirline();
					break;
		
				case 2:
					flightListbydestCity();
					break;
		
				case 3:
					flightListbyDate();
					break;
					
				case 4:
					viewBookingsofFlight();
					break;
					
				case 5:
					viewPassengerListofFlight();
					break;
					
				case 6:
					break view;
					
				default:
					System.out.println("\nSelect from the given menu!!!!!");
					break;
		
		
		}//view switch
		} catch (NumberFormatException | IOException e) {
			
			System.out.println("Please check the give input");
		}
		
		}//while
		
		
	}
	
	private static void viewPassengerListofFlight() {
		BookingInformationService service=new BookingInformationServiceImpl(); //FlightInformationServiceImpl object
		System.out.println("Enter flight number to view passenger list");
		try {
			int flightNum=Integer.parseInt(br.readLine());
			try {
				List<BookingInformationDto> list=service.getPassengersListofFlight(flightNum);
				for(BookingInformationDto dto:list) {
					System.out.println("\nBooking Id: "+dto.getBookingId());
					System.out.println("Flight number: "+dto.getFlightno());
					System.out.println("No of Passengers: "+dto.getPassengers());
					System.out.println("class type: "+dto.getClassType());
					System.out.println("Seat numbers: "+dto.getSeatNumber());
				}
			} catch (ReservationException e) {
				System.out.println("Error Occured "+e.getMessage());
			}
		} catch (IOException e) {
			System.out.println("Invalid data entered");
		}
	}








	private static boolean authentication() {
		
		boolean validation=false;
		try {
			System.out.println("\n\nEnter UserName");
			String userName=br.readLine();
			System.out.println("Enter Password");
			String password=br.readLine();
			
			UsersServiceImpl ser=new UsersServiceImpl();  //UsersService object

			
			validation=false;
			
				validation = ser.validateCredentials(userName, password);
				if(validation) {
					validation=true;
				}
		} catch (IOException | UsersException e) {
			validation=false;
		}
		 
		
		return validation;
		
	}
	
	  private static void flightListbyAirline() throws IOException {
		
		System.out.println("Enter Name of Airline");
		String airLineName=br.readLine();
		FlightInformationServiceImpl service=new FlightInformationServiceImpl();   //FlightInformationServiceImpl object

			
		try {
			List<FlightInformationDto> list=service.getFlightDetailsbyAirlineName(airLineName);
			
				if(list.size()==0) {
					System.out.println("There are no flights with the name "+airLineName);
				}
				else
			
				for(FlightInformationDto list1:list) {
					System.out.println("\n\nFLight Number:  "+list1.getFlightNo());
					System.out.println("Airline:  "+list1.getAirLine());
					System.out.println("Departure City:  "+list1.getDep_City());
					System.out.println("Arrival City:  "+list1.getArr_City());
					System.out.println("Departure Date:  "+list1.getDep_Date());
					System.out.println("Arrival Date:  "+list1.getArr_Date());
					System.out.println("Departure Time(HH:mm):  "+list1.getDep_Time());
					System.out.println("Arrival Time(HH:mm):  "+list1.getArr_Time());
					System.out.println("Firstclass Seats:  "+list1.getFirstSeats());
					System.out.println("Firstclass Seatfare:  "+list1.getFirstSeatFare());
					System.out.println("Business class Seats:  "+list1.getBussSeats());
					System.out.println("Business class Seatfare:  "+list1.getBussSeatsFare());
					
				}
			
		} catch (FlightInformationException e) {
		
			System.out.println("Error Occured:"+e.getMessage());
		}
		
	}
	  
	  
	  
	  
	  
	  private static void flightListbyDate() throws IOException {
		  
			FlightInformationServiceImpl service=new FlightInformationServiceImpl();   //FlightInformationServiceImpl object

		  System.out.println("Enter date(dd-MM-yyyy) to search flights");
			String date=br.readLine();
			DateTimeFormatter Format=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate date1=LocalDate.parse(date, Format);
			try {
				List<FlightInformationDto> list4=service.getFlightDetailsbyDate(date1);
					if(list4.size()==0) {
						System.out.println("There are no flights with the date "+date1);
					}
					else
				
					for(FlightInformationDto list5:list4) {
						System.out.println("\n\nFLight Number:  "+list5.getFlightNo());
						System.out.println("Airline:  "+list5.getAirLine());
						System.out.println("Departure City:  "+list5.getDep_City());
						System.out.println("Arrival City:  "+list5.getArr_City());
						System.out.println("Departure Date:  "+list5.getDep_Date());
						System.out.println("Arrival Date:  "+list5.getArr_Date());
						System.out.println("Departure Time(HH:mm):  "+list5.getDep_Time());
						System.out.println("Arrival Time(HH:mm):  "+list5.getArr_Time());
						System.out.println("Firstclass Seats:  "+list5.getFirstSeats());
						System.out.println("Firstclass Seatfare:  "+list5.getFirstSeatFare());
						System.out.println("Business class Seats:  "+list5.getBussSeats());
						System.out.println("Business class Seatfare:  "+list5.getBussSeatsFare());
						
					}
				} catch (FlightInformationException e) {
					System.out.println("Error Occured:"+e.getMessage());

				}
		  
		  
	  }
	  
	  
	  
	  
	  private static void flightListbydestCity() throws IOException {
		  
			FlightInformationServiceImpl service=new FlightInformationServiceImpl();   //FlightInformationServiceImpl object

			System.out.println("Enter a destination city to search flights");
			String destinationCity=br.readLine();
			try {
			List<FlightInformationDto> list2=service.getFlightDetailsbyDestCity(destinationCity);
				if(list2.size()==0) {
					System.out.println("There are no flights with the destination city "+destinationCity);
				}
				else
			
				for(FlightInformationDto list3:list2) {
					System.out.println("\n\nFLight Number:  "+list3.getFlightNo());
					System.out.println("Airline:  "+list3.getAirLine());
					System.out.println("Departure City:  "+list3.getDep_City());
					System.out.println("Arrival City:  "+list3.getArr_City());
					System.out.println("Departure Date:  "+list3.getDep_Date());
					System.out.println("Arrival Date:  "+list3.getArr_Date());
					System.out.println("Departure Time(HH:mm):  "+list3.getDep_Time());
					System.out.println("Arrival Time(HH:mm):  "+list3.getArr_Time());
					System.out.println("Firstclass Seats:  "+list3.getFirstSeats());
					System.out.println("Firstclass Seatfare:  "+list3.getFirstSeatFare());
					System.out.println("Business class Seats:  "+list3.getBussSeats());
					System.out.println("Business class Seatfare:  "+list3.getBussSeatsFare());
					
				}
			} catch (FlightInformationException e) {
				System.out.println("Error Occured:"+e.getMessage());

			}
		 
	  	}


	  public static void viewBookingsofFlight() {
		  try {
		  System.out.println("Enter flight number to display bookings");
		 int flightNo=Integer.parseInt(br.readLine());
		BookingInformationService service=new BookingInformationServiceImpl(); //FlightInformationServiceImpl object
		
		
		try {
			List<BookingInformationDto> bookinglist=service.getBookingDetails(flightNo);
			if(bookinglist.size()==0) {
				System.out.println("There are no bookings for this flight");
			} else
				for(BookingInformationDto book:bookinglist) {
			System.out.println("\nBooking Id: "+book.getBookingId());
			System.out.println("Flight Number: "+book.getFlightno());
			System.out.println("Customer Email: "+book.getEmail());
			System.out.println("Number of Passengers: "+book.getPassengers());
			System.out.println("CLass Type: "+book.getClassType());
			System.out.println("Total Fare: "+book.getTotalFare());
			System.out.println("Seat Numbers: "+book.getSeatNumber());
			System.out.println("Creditcard Info: "+book.getCreditCardInfo());
			System.out.println("Source City: "+book.getSourceCity());
			System.out.println("Destination City: "+book.getDestCity());
				}
		} 
		
		 catch (ReservationException e) {
				System.out.println("Error Occured"+e.getMessage());
			}
		} catch (IOException e) {
			System.out.println("Please check the given data");
		}
		 
		  
		  
	  }
	
	  public static void printAllFLightDetails() {
		  
		  FlightInformationService service=new FlightInformationServiceImpl();
		  try {
			List<FlightInformationDto> listFlight=service.getAllFlightDetails();
			for(FlightInformationDto dto:listFlight) {
				System.out.println("\n\nFLight number:  "+dto.getFlightNo());
				System.out.println("Airline:  "+dto.getAirLine());
				System.out.println("Departure City  "+dto.getDep_City());
				System.out.println("Arrival City:  "+dto.getArr_City());
				System.out.println("Departure Date:  "+dto.getDep_Date());
				System.out.println("Arrival Date:  "+dto.getArr_Date());
				System.out.println("Departure Time(HH:mm):  "+dto.getDep_Time());
				System.out.println("Arrival Time(HH:mm):  "+dto.getArr_Time());
				System.out.println("Firstclass Seats:  "+dto.getFirstSeats());
				System.out.println("Firstclass Seatfare:  "+dto.getFirstSeatFare());
				System.out.println("Business class Seats:  "+dto.getBussSeats());
				System.out.println("Business class Seatfare:  "+dto.getBussSeatsFare());
				
			}
		} catch (FlightInformationException e) {
			System.out.println("Error Occured"+e.getMessage());
		}
		  
	  }
	
	
	
	
	
	
	
}
