package com.cg.ars.dto;

import java.time.LocalDate;

public class FlightInformationDto {
	
	private int flightNo;
	//private String flightNo;
	private String airLine;
	private String dep_City;
	private String arr_City;
	private LocalDate dep_Date;
	private LocalDate arr_Date;
	public LocalDate getDep_Date() {
		return dep_Date;
	}
	public void setDep_Date(LocalDate dep_Date) {
		this.dep_Date = dep_Date;
	}
	public LocalDate getArr_Date() {
		return arr_Date;
	}
	public void setArr_Date(LocalDate arr_Date) {
		this.arr_Date = arr_Date;
	}
	private String dep_Time;
	private String arr_Time;
	private int firstSeats;
	private double firstSeatFare;
	private int bussSeats;
	private double bussSeatsFare;
	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirLine() {
		return airLine;
	}
	/*public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}*/
	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}
	public String getDep_City() {
		return dep_City;
	}
	public void setDep_City(String dep_City) {
		this.dep_City = dep_City;
	}
	public String getArr_City() {
		return arr_City;
	}
	public void setArr_City(String arr_City) {
		this.arr_City = arr_City;
	}
	
	
	public String getDep_Time() {
		return dep_Time;
	}
	public void setDep_Time(String dep_Time) {
		this.dep_Time = dep_Time;
	}
	public String getArr_Time() {
		return arr_Time;
	}
	public void setArr_Time(String arr_Time) {
		this.arr_Time = arr_Time;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public double getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public double getBussSeatsFare() {
		return bussSeatsFare;
	}
	public void setBussSeatsFare(double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}
	

}
