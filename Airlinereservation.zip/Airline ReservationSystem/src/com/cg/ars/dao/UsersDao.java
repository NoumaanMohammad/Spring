package com.cg.ars.dao;

import com.cg.ars.dto.UsersDto;
import com.cg.ars.exception.ReservationException;
import com.cg.ars.exception.UsersException;

public interface UsersDao {
	public boolean validateCredentials(String username,String password)  throws ReservationException;

}
