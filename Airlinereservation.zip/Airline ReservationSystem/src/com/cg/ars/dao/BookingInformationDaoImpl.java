package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;
import com.cg.ars.util.DatabaseConnection;

public class BookingInformationDaoImpl implements BookingInformationDao {

	@Override
	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException {
		
		String sql="select * from bookinginformation where flightno="+flightNo;
		List<BookingInformationDto> list=new ArrayList<BookingInformationDto>();
		Connection con=DatabaseConnection.getConnection();
		Statement s;
		try {
			s = con.createStatement();
		ResultSet rs=s.executeQuery(sql);
		while(rs.next()) {
			BookingInformationDto dto=new BookingInformationDto();
			dto.setBookingId(rs.getInt("booking_id"));
			dto.setFlightno(rs.getInt("flightno"));
			dto.setEmail(rs.getString("cust_email"));
			dto.setPassengers(rs.getInt("no_of_passengers"));
			dto.setClassType(rs.getString("class_type"));
			dto.setTotalFare(rs.getDouble("total_fare"));
			dto.setSeatNumber(rs.getString("seat_number"));
			dto.setCreditCardInfo(rs.getString("creditcard_info"));
			dto.setSourceCity(rs.getString("src_city"));
			dto.setDestCity(rs.getString("dest_city"));
			list.add(dto);
		}
		} catch (SQLException e) {
			throw new ReservationException("Entered invalid flight number");
		}
		
		return list;
	}

	@Override
	public List<BookingInformationDto> getPassengerList(int flightNo)
			throws ReservationException {
		
		String sql="select booking_id,flightno,no_of_passengers,class_type,seat_number from bookinginformation where flightno=?";
		List<BookingInformationDto> list=new ArrayList<BookingInformationDto>();
		Connection con=DatabaseConnection.getConnection();
		PreparedStatement s;
		try {
			s = con.prepareStatement(sql);
					s.setInt(1,flightNo );
		ResultSet rs=s.executeQuery();
		while(rs.next()) {
			BookingInformationDto dto=new BookingInformationDto();
			dto.setBookingId(rs.getInt("booking_id"));
			dto.setFlightno(rs.getInt("flightno"));
			dto.setPassengers(rs.getInt("no_of_passengers"));
			dto.setClassType(rs.getString("class_type"));
			dto.setSeatNumber(rs.getString("seat_number"));
			
			list.add(dto);
		}
		} catch (SQLException e) {
			
			throw new ReservationException("Entered invalid flight number");
		}
		
		return list;
	}

	@Override
	public BookingInformationDto getBookingDetailsForUser(int bookId) throws ReservationException {
		
		String sql="select * from bookinginformation where booking_id=?";
		BookingInformationDto dto=new BookingInformationDto();
		Connection con=DatabaseConnection.getConnection();
		
		try {
			PreparedStatement s=con.prepareStatement(sql);
			s.setInt(1, bookId);
			ResultSet rs=s.executeQuery();
			if(rs.next()) {
				dto.setBookingId(bookId);
				dto.setFlightno(rs.getInt(2));
				dto.setEmail(rs.getString(3));
				dto.setPassengers(rs.getInt(4));
				dto.setClassType(rs.getString(5));
				dto.setTotalFare(rs.getDouble(6));
				dto.setSeatNumber(rs.getString(7));
				dto.setCreditCardInfo(rs.getString(8));
				dto.setSourceCity(rs.getString(9));
				dto.setDestCity(rs.getString(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			//throw new ReservationException("cannot able to retrieve data");
		}
		return dto;
	}

	@Override
	public int cancelBookingDetailsForUser(BookingInformationDto book) throws ReservationException {

		String sqlDelete="delete from bookinginformation where booking_id="+book.getBookingId();
		String sqlUpdate="update flightinformation set firstseats=firstseats+? where flightno=?";
		String sqlUpdate1="update flightinformation set bussseats=bussseats+? where flightno=?";
		Connection con=DatabaseConnection.getConnection();
		int deletion=0,updation=0;
		try {
			Statement s=con.createStatement();
			deletion=s.executeUpdate(sqlDelete);
				if(deletion!=0) {
					if((book.getClassType().toLowerCase()).contains("first")) {
					PreparedStatement ps=con.prepareStatement(sqlUpdate);
					ps.setInt(1, book.getPassengers());
					ps.setInt(2, book.getFlightno());
						updation=ps.executeUpdate();
					} else if(book.getClassType().toLowerCase().contains("bus")) {
						
						PreparedStatement ps=con.prepareStatement(sqlUpdate1);
						ps.setInt(1, book.getPassengers());
						ps.setInt(2, book.getFlightno());
							updation=ps.executeUpdate();
					}
				}
		} catch (SQLException e) {
			throw new ReservationException("NOt able to cancel the ticket");
		}
		
		return updation;
	}

	@Override
	public int bookTicketForUser(BookingInformationDto dto) throws ReservationException {
		String sql="insert into bookinginformation(booking_id,flightno,cust_email,no_of_passengers"
				+ ",class_type,total_fare,seat_number,creditcard_info,src_city,dest_city) values"
				+ "(booking_id_seq.nextval,?,?,?,?,?,?,?,?,?)";
		
		int status=0;
		int id=0;
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, dto.getFlightno());
			ps.setString(2, dto.getEmail());
			ps.setInt(3, dto.getPassengers());
			ps.setString(4, dto.getClassType());
			ps.setDouble(5, dto.getTotalFare());
			ps.setString(6, dto.getSeatNumber());
			ps.setString(7, dto.getCreditCardInfo());
			ps.setString(8, dto.getSourceCity());
			ps.setString(9, dto.getDestCity());
			status=ps.executeUpdate();
			if(status!=0) {
				Statement s=con.createStatement();
				ResultSet rs=s.executeQuery("select bookingid_seq.currval from dual");
				if(rs.next()) {
					id=rs.getInt(1);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			//throw new ReservationException("canot able to book a ticket");
		}
		
		return id;
	}

	@Override
	public int sequenceForSeatNumber() throws FlightInformationException {
		String sequence="select seat_number_seq.nextval from dual";
		Connection con=DatabaseConnection.getConnection();
		int row=0;
		try {
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery(sequence);
			if(rs.next()) {
				row=rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new FlightInformationException("not able to generate seat number sequence");
		}
		return row;
	}

	@Override
	public int updateTicketDEtailsforUser(BookingInformationDto dto) throws FlightInformationException {

		String updateSql="update bookinginformation set flightno=?,cust_email=?,"
				+ "no_of_passengers=?,class_type=?,total_fare=?,seat_number=?,creditcard_info=?"
				+ "src_city=?,dest_city=?";
		int row=0;
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(updateSql);
			ps.setInt(1, dto.getFlightno());
			ps.setString(2, dto.getEmail());
			ps.setInt(3, dto.getPassengers());
			ps.setString(4, dto.getClassType());
			ps.setDouble(5, dto.getTotalFare());
			ps.setString(6, dto.getSeatNumber());
			ps.setString(7, dto.getCreditCardInfo());
			ps.setString(8, dto.getSourceCity());
			ps.setString(9, dto.getDestCity());
			row=ps.executeUpdate();
		} catch (SQLException e) {
			throw new FlightInformationException("not able to update");
		}
		
				
		return row;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
