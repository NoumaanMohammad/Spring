package com.cg.ars.exception;

public class UsersException extends ReservationException {

	public UsersException(String msg) {
		super(msg);
	}
}
