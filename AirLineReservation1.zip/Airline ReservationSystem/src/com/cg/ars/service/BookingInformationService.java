package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.exception.ReservationException;

public interface BookingInformationService {
	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException;
	public List<BookingInformationDto> getPassengersListofFlight(int flightNo) throws ReservationException;

	
}
