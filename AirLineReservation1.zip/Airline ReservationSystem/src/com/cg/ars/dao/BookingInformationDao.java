package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.exception.ReservationException;

public interface BookingInformationDao {

	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException;
	public  List<BookingInformationDto> getPassengerList(int flightNo) throws ReservationException;
}
