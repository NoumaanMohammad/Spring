package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.cg.ars.dto.UsersDto;
import com.cg.ars.exception.UsersException;
import com.cg.ars.util.DatabaseConnection;

public class UsersDaoImpl implements UsersDao{

	@Override
	public boolean validateCredentials(String username,String password) throws UsersException {
		String sql="select * from users where role='Admin' and username=? and password=?";
		UsersDto dto = null;
		boolean Validation=false;
		try {
			Connection con=DatabaseConnection.getConnection();

			PreparedStatement s=con.prepareStatement(sql);
			s.setString(1, username);
			s.setString(2, password);

			ResultSet rs=s.executeQuery();
			
			while(rs.next()){
			Validation=true;
			}
			
		} catch (SQLException e) {
			Validation= false;
		}
		return Validation;
	}

}
