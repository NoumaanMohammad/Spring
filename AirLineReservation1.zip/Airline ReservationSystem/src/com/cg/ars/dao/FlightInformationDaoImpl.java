package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.FlightInformationDto;
import com.cg.ars.exception.FlightInformationException;
import com.cg.ars.util.DatabaseConnection;

public class FlightInformationDaoImpl implements FlightInformationDao{

	@Override
	public List<FlightInformationDto> getFlightDetailsbyAirlineName(
			String Airline) throws FlightInformationException {
		
		String sql="select * from flightinformation where lower(airline)=lower(?)";
		
		
		
		List<FlightInformationDto> list=new ArrayList<FlightInformationDto>();
		
		try {
			Connection con=DatabaseConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, Airline);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				FlightInformationDto dto=new FlightInformationDto();
				dto.setFlightNo(rs.getInt(1));
				dto.setAirLine(rs.getString(2));
				dto.setDep_City(rs.getString(3));
				dto.setArr_City(rs.getString(4));
				dto.setDep_Date(rs.getDate(5).toLocalDate());
				dto.setArr_Date(rs.getDate(6).toLocalDate());
				dto.setDep_Time(rs.getString(7));
				dto.setArr_Time(rs.getString(8));
				dto.setFirstSeats(rs.getInt(9));
				dto.setFirstSeatFare(rs.getDouble(10));
				dto.setBussSeats(rs.getInt(11));
				dto.setBussSeatsFare(rs.getDouble(12));
				
				list.add(dto);
				
				
			}
		} catch (SQLException e) {
			throw new FlightInformationException("Cannot able to retrieve data from database");
		}
		
		
		
		return list;
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsbyDestCity(
			String destCity) throws FlightInformationException {
		
		String sql1="select * from flightinformation where lower(arr_city)=lower(?)";
		
		List<FlightInformationDto> list1=new ArrayList<FlightInformationDto>();
		
		try {
			Connection con=DatabaseConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(sql1);
			ps.setString(1, destCity);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				FlightInformationDto dto=new FlightInformationDto();
				dto.setFlightNo(rs.getInt(1));
				dto.setAirLine(rs.getString(2));
				dto.setDep_City(rs.getString(3));
				dto.setArr_City(rs.getString(4));
				dto.setDep_Date(rs.getDate(5).toLocalDate());
				dto.setArr_Date(rs.getDate(6).toLocalDate());
				dto.setDep_Time(rs.getString(7));
				dto.setArr_Time(rs.getString(8));
				dto.setFirstSeats(rs.getInt(9));
				dto.setFirstSeatFare(rs.getDouble(10));
				dto.setBussSeats(rs.getInt(11));
				dto.setBussSeatsFare(rs.getDouble(12));
				
				list1.add(dto);
				
				
			}
		} catch (SQLException e) {
			throw new FlightInformationException("Cannot able to retrieve data from database");
		}
		


		return list1;
	}

	@Override
	public List<FlightInformationDto> getFlightDetailsbyDate(
			LocalDate ldate) throws FlightInformationException {
		String sql="select * from flightinformation where dep_date=?";
			
List<FlightInformationDto> list1=new ArrayList<FlightInformationDto>();
		
		try {
			Connection con=DatabaseConnection.getConnection();
			PreparedStatement s=con.prepareStatement(sql);
			s.setDate(1, java.sql.Date.valueOf(ldate));
			ResultSet rs=s.executeQuery();
			
			while(rs.next()) {
				
				FlightInformationDto dto=new FlightInformationDto();
				dto.setFlightNo(rs.getInt(1));
				dto.setAirLine(rs.getString(2));
				dto.setDep_City(rs.getString(3));
				dto.setArr_City(rs.getString(4));
				dto.setDep_Date(rs.getDate(5).toLocalDate());
				dto.setArr_Date(rs.getDate(6).toLocalDate());
				dto.setDep_Time(rs.getString(7));
				dto.setArr_Time(rs.getString(8));
				dto.setFirstSeats(rs.getInt(9));
				dto.setFirstSeatFare(rs.getDouble(10));
				dto.setBussSeats(rs.getInt(11));
				dto.setBussSeatsFare(rs.getDouble(12));
				
				list1.add(dto);
				
				
			}
		} catch (SQLException e) {
			throw new FlightInformationException("Cannot able to retrieve data from database");
		}
		
		return list1;
	}

	@Override
	public int updateFlightSchedule(FlightInformationDto flight)
			throws FlightInformationException {
		int rows=0;
		String sql="update flightinformation set dep_date=?,arr_date=?,dep_time=?,arr_time=? where flightno=?";
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setDate(1, Date.valueOf(flight.getDep_Date()));
			ps.setDate(2, Date.valueOf(flight.getArr_Date()));
			ps.setString(3, flight.getDep_Time());
			ps.setString(4, flight.getArr_Time());
			ps.setInt(5, flight.getFlightNo());
			
			rows=ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			//throw new FlightInformationException("cannot able to update data!!");
		}
		return rows;
	}

	@Override
	public int addNewFlightDetails(FlightInformationDto flight)
			throws FlightInformationException {
		String sql="insert into flightinformation(flightno,airline,dep_city,arr_city,dep_date,arr_date,dep_time,arr_time,firstseats,firstseatfare,bussseats,bussseatsfare) "
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?)";
		int rows=0;
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, flight.getFlightNo());
			ps.setString(2, flight.getAirLine());
			ps.setString(3, flight.getDep_City());
			ps.setString(4, flight.getArr_City());
			ps.setDate(5, Date.valueOf(flight.getDep_Date()));
			ps.setDate(6, Date.valueOf(flight.getArr_Date()));
			ps.setString(7, flight.getDep_Time());
			ps.setString(8, flight.getArr_Time());
			ps.setInt(9, flight.getFirstSeats());
			ps.setDouble(10, flight.getFirstSeatFare());
			ps.setInt(11, flight.getBussSeats());
			ps.setDouble(12, flight.getBussSeatsFare());
			rows=ps.executeUpdate();
		} catch (SQLException e) {
			throw new FlightInformationException("Cannot able to insert data...check data once");
			
		}
		return rows;
	}

	@Override
	public int updateFareDetails(int flightNo, double busFare, double FirstFare)
			throws FlightInformationException {
		int result=0;
			String sql="update flightinformation set firstseatfare=?,bussseatsfare=? where flightno=?";
			Connection con=DatabaseConnection.getConnection();
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setDouble(1, FirstFare);
				ps.setDouble(2, busFare);
				ps.setInt(3, flightNo);
				result=ps.executeUpdate();
				
			} catch (SQLException e) {
				
				throw new FlightInformationException("Enter valid flight number");
			}
		return result;
	}

	@Override
	public int updateCityDetails(int flightNo, String deCity, String arrCity)
			throws FlightInformationException {
		
		int rows=0;
		String sql="update flightinformation set dep_city=?,arr_city=? where flightno=?";
		Connection con=DatabaseConnection.getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(3, flightNo);
			ps.setString(1, deCity);
			ps.setString(2, arrCity);
			rows=ps.executeUpdate();
		} catch (SQLException e) {
			throw new FlightInformationException("Cannot able to update!!Check the data");
		}
		
		return rows;
	}

	@Override
	public List<FlightInformationDto> getAllFlightDetails()
			throws FlightInformationException {
		
		List<FlightInformationDto> list=new ArrayList<FlightInformationDto>();
			String sql="select * from flightinformation";
			Connection con=DatabaseConnection.getConnection();
			try {
				Statement s=con.createStatement();
				ResultSet rs=s.executeQuery(sql);
					while(rs.next()) {
				FlightInformationDto dto=new FlightInformationDto();
				dto.setFlightNo(rs.getInt(1));
				dto.setAirLine(rs.getString(2));
				dto.setDep_City(rs.getString(3));
				dto.setArr_City(rs.getString(4));
				dto.setDep_Date(rs.getDate(5).toLocalDate());
				dto.setArr_Date(rs.getDate(6).toLocalDate());
				dto.setDep_Time(rs.getString(7));
				dto.setArr_Time(rs.getString(8));
				dto.setFirstSeats(rs.getInt(9));
				dto.setFirstSeatFare(rs.getDouble(10));
				dto.setBussSeats(rs.getInt(11));
				dto.setBussSeatsFare(rs.getDouble(12));
				list.add(dto);
				
					}
				
			} catch (SQLException e) {
				e.printStackTrace();
			System.out.println("Cannot able to retrieve data from database");
			}
			
		return list;
	}

	
}
