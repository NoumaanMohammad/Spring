package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.BookingInformationDto;
import com.cg.ars.exception.ReservationException;
import com.cg.ars.util.DatabaseConnection;

public class BookingInformationDaoImpl implements BookingInformationDao {

	@Override
	public List<BookingInformationDto> getBookingDetails(int flightNo) throws ReservationException {
		
		String sql="select * from bookinginformation where flightno="+flightNo;
		List<BookingInformationDto> list=new ArrayList<BookingInformationDto>();
		Connection con=DatabaseConnection.getConnection();
		Statement s;
		try {
			s = con.createStatement();
		ResultSet rs=s.executeQuery(sql);
		while(rs.next()) {
			BookingInformationDto dto=new BookingInformationDto();
			dto.setBookingId(rs.getInt("booking_id"));
			dto.setFlightno(rs.getInt("flightno"));
			dto.setEmail(rs.getString("cust_email"));
			dto.setPassengers(rs.getInt("no_of_passengers"));
			dto.setClassType(rs.getString("class_type"));
			dto.setTotalFare(rs.getDouble("total_fare"));
			dto.setSeatNumber(rs.getString("seat_number"));
			dto.setCreditCardInfo(rs.getString("creditcard_info"));
			dto.setSourceCity(rs.getString("src_city"));
			dto.setDestCity(rs.getString("dest_city"));
			list.add(dto);
		}
		} catch (SQLException e) {
			throw new ReservationException("Entered invalid flight number");
		}
		
		return list;
	}

	@Override
	public List<BookingInformationDto> getPassengerList(int flightNo)
			throws ReservationException {
		
		String sql="select booking_id,flightno,no_of_passengers,class_type,seat_number from bookinginformation where flightno=?";
		List<BookingInformationDto> list=new ArrayList<BookingInformationDto>();
		Connection con=DatabaseConnection.getConnection();
		PreparedStatement s;
		try {
			s = con.prepareStatement(sql);
					s.setInt(1,flightNo );
		ResultSet rs=s.executeQuery();
		while(rs.next()) {
			BookingInformationDto dto=new BookingInformationDto();
			dto.setBookingId(rs.getInt("booking_id"));
			dto.setFlightno(rs.getInt("flightno"));
			dto.setPassengers(rs.getInt("no_of_passengers"));
			dto.setClassType(rs.getString("class_type"));
			dto.setSeatNumber(rs.getString("seat_number"));
			
			list.add(dto);
		}
		} catch (SQLException e) {
			
			throw new ReservationException("Entered invalid flight number");
		}
		
		return list;
	}

}
