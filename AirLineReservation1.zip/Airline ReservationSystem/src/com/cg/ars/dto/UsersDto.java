package com.cg.ars.dto;

public class UsersDto {
	private String UserName;
	private String Password;
	private String Role;
	private long MobileNum;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public long getMobileNum() {
		return MobileNum;
	}
	public void setMobileNum(long mobileNum) {
		MobileNum = mobileNum;
	}
}
