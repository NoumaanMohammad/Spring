
create table users(username varchar2(20), password varchar2(20), role varchar2(10), mobile_no number(10));


 insert into users values('Admin',1234,'Admin',7396735626);
 
 
 create table flightinformation(flightno number(5) primary key,airline varchar2(20),dep_city varchar2(20), arr_city varchar2(20), dep_date date, arr_date date, dep_time varchar2(20), arr_time varchar2(20), FirstSeats number, FirstSeatFare number(10,2), BussSeats number, BussSeatsFare number(10,2));
 
 
 
insert into flightinformation values(10001,'Air India','Delhi','Chennai','08-AUG-2018','08-AUG-2018','11:00','14:05',80,7000,120,4000);

insert into flightinformation values(10002,'Air India','Chennai','Delhi','09-AUG-2018','09-AUG-2018','8:00','11:30',80,7000,120,4000);

insert into flightinformation values(10003,'Air India','Kolkata','Delhi','09-AUG-2018','10-AUG-2018','22:30','01:40',80,6000,120,2800);

insert into flightinformation values(10004,'Air India','Delhi','Kolkata','10-AUG-2018','10-AUG-2018','04:00','07:40',80,6000,120,2800);




insert into flightinformation values(10005,'Jet Airways','Mumbai','Hyderabad','09-AUG-2018','09-AUG-2018','18:00','21:30',50,7000,100,3000);

insert into flightinformation values(10006,'Jet Airways','Hyderabad','Mumbai','09-AUG-2018','09-AUG-2018','12:15','16:00',50,7000,100,3000);

insert into flightinformation values(10007,'Jet Airways','Bangalore','Mumbai','11-AUG-2018','11-AUG-2018','00:30','03:25',50,8000,100,3000);

insert into flightinformation values(10008,'Jet Airways','Mumbai','Bangalore','11-AUG-2018','11-AUG-2018','09:45','13:50',50,8000,100,3000);




insert into flightinformation values(10009,'IndiGo','Pune','Trivendrum','11-AUG-2018','11-AUG-2018','17:00','20:50',100,6500,100,3600);

insert into flightinformation values(10010,'IndiGo','Trivendrum','Pune','11-AUG-2018','12-AUG-2018','22:00','01:50',100,6500,100,3600);

insert into flightinformation values(10011,'IndiGo','Trivendrum','Gandhinagar','12-AUG-2018','12-AUG-2018','08:30','12:15',100,7500,100,4200);

insert into flightinformation values(10012,'IndiGo','Gandhinagar','Trivendrum','12-AUG-2018','12-AUG-2018','16:05','20:00',100,7500,100,4200);




insert into flightinformation values(10013,'SpiceJet','Delhi','Hyderabad','12-AUG-2018','12-AUG-2018','21:00','00:40',100,10000,100,6000);

insert into flightinformation values(10014,'SpiceJet','Hyderabad','Delhi','12-AUG-2018','12-AUG-2018','05:30','09:10',100,10000,100,6000);

insert into flightinformation values(10015,'SpiceJet','Chennai','Kolkata','13-AUG-2018','13-AUG-2018','10:30','14:10',100,16000,100,7900);

insert into flightinformation values(10016,'SpiceJet','Kolkata','Chennai','13-AUG-2018','13-AUG-2018','18:30','22:10',100,16000,100,7900);



insert into flightinformation values(10017,'Air Deccan','Pune','Hyderabad','13-AUG-2018','13-AUG-2018','10:30','13:10',50,12000,100,6700);

insert into flightinformation values(10018,'Air Deccan','Hyderabad','Pune','14-AUG-2018','14-AUG-2018','19:15','22:30',50,12000,100,6700);

insert into flightinformation values(10019,'Air Deccan','Bangalore','Pune','14-AUG-2018','15-AUG-2018','22:15','00:30',50,11000,100,6000);

insert into flightinformation values(10020,'Air Deccan','Pune','Bangalore','15-AUG-2018','15-AUG-2018','13:30','16:05',50,11000,100,6000);



insert into flightinformation values(10021,'Vistara','Pune','Chennai','15-AUG-2018','15-AUG-2018','05:30','09:05',100,11000,100,6000);

insert into flightinformation values(10022,'Vistara','Chennai','Pune','15-AUG-2018','15-AUG-2018','11:00','14:05',100,11000,100,6000);

insert into flightinformation values(10023,'Vistara','Gandhinagar','Delhi','15-AUG-2018','16-AUG-2018','23:00','02:35',100,7000,100,3200);

insert into flightinformation values(10024,'Vistara','Delhi','Gandhinagar','16-AUG-2018','16-AUG-2018','15:20','18:35',100,7000,100,3200);




insert into flightinformation values(10025,'TruJet','Mumbai','Panaji','16-AUG-2018','16-AUG-2018','19:20','22:35',120,8500,100,3700);

insert into flightinformation values(10026,'TruJet','Panaji','Mumbai','17-AUG-2018','17-AUG-2018','18:20','23:35',120,8500,100,3700);

insert into flightinformation values(10027,'TruJet','Hyderabad','Panaji','17-AUG-2018','17-AUG-2018','04:10','07:35',120,9500,100,4000);

insert into flightinformation values(10028,'TruJet','Panaji','Hyderabad','17-AUG-2018','17-AUG-2018','09:10','11:50',120,9500,100,4000);








 create table BookingInformation(
 Booking_id number primary key,
 flightno number(5) references flightinformation(flightno),
 cust_email varchar2(20),
 no_of_passengers number,
 class_type varchar2(10),
 total_fare number(6,2),
 seat_number varchar2(30),
 CreditCard_info varchar2(60),
 src_city varchar2(10),
 dest_city varchar2(10));
 
 
 
 create sequence bookingid_seq start with 100;
 
 
 
 
 insert into BookingInformation values(bookingid_seq.nextval,10001,'jhgdsf@gmail.com',2,'business',3500,'Al12,AL13','7894561230789456,123','Delhi','Chennai');
 
 
 
 
 
 